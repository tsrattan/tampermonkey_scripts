NORD DASHBOARD — JAVASCRIPT BOOKMARKS

Extract the ZIP. Keep dashboard.html and bookmarks.js in the same folder.
Open dashboard.html in Edge. No installation needed.

BROWSER EDITING
1. Click Connect bookmarks.js and select the file beside dashboard.html.
2. Allow read/write access if prompted.
3. Add a bookmark, or use Edit on any tile. Delete is inside Edit.
4. Wait for the Saved message before refreshing. Refresh reads bookmarks.js.
5. Reconnect after refreshing/reopening before making further edits.

EDIT IN NOTEPAD
Edit bookmarks.js, preserve window.NORD_DASHBOARD = and the final semicolon,
and use valid JSON inside (double quotes, no trailing commas).
Save, then refresh the dashboard. Do not edit in Notepad and the dashboard
at the same time: refresh to load external changes before browser editing.

If direct writing is unavailable or blocked, Download bookmarks.js and manually
replace the file beside the HTML. Downloads may have a numbered suffix: rename
the replacement to bookmarks.js. A download alone does not replace the original.
Unsaved changes trigger a browser warning on refresh/close.

The page does not cache bookmarks in browser storage. JSON import replaces the
current list and saves to the connected JS file, or remains unsaved if unconnected.
Only HTTP and HTTPS bookmark URLs are supported, including intranet hostnames.
The clock follows your PC timezone. Web search offers Google, Bing and DuckDuckGo.
No external assets or analytics. Search and bookmarks visit their selected sites.

Workplace policy can block scripts or file access. This cannot guarantee that
Defender will accept the files. If flagged, ask IT to review; do not bypass it.

LAYOUT
Eight default categories form four columns and two rows on desktop.
Smaller windows use two columns or one. Additional categories create more rows.
Rename categories in bookmarks.js; bookmarks can be moved using Edit.

Use Layout to change heading, columns (1–6), and rows per page (1–6).
Settings are saved with bookmarks. Extra categories use Previous/Next pages.
