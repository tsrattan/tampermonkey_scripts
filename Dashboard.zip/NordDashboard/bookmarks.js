window.NORD_DASHBOARD = {
  "settings": {
    "title": "My workspace",
    "columns": 4,
    "rows": 2
  },
  "bookmarks": {
    "Work": [
      {
        "name": "Outlook",
        "url": "https://outlook.office.com"
      },
      {
        "name": "Microsoft Teams",
        "url": "https://teams.microsoft.com"
      }
    ],
    "Work instructions": [],
    "Reference": [],
    "Training": [],
    "Projects": [],
    "Useful tools": [],
    "Frequently used": [],
    "Personal": []
  }
};
