PORTABLE TEXT EXPANDER - CLEAN EDITION

This package excludes personal snippets and bundled original archives.
The Snippet Manager and built-in Windows Notepad compatibility fix are included.

1. Use Windows Extract All to extract this ZIP into a new folder.
2. Run Start Text Expander.bat. No installation or administrator rights needed.
3. Right-click the TE tray icon and choose Manage snippets.
4. Click New to add your snippets. Changes are backed up locally.

The match folder is intentionally empty. Add snippets using the manager, or
copy your own YAML files into match. Settings are in config/default.yml.
Windows Notepad automatically uses clipboard paste when backend is auto.

Advanced YAML is protected from basic editing; use Open YAML for those entries.
Backups are stored in the app folder. Do not include personal snippet files or
backups when sharing your copy of this app.
