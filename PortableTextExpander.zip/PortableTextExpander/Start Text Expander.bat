@echo off
rem Starts Portable Text Expander (no install needed). Look for the blue "TE" icon near the clock.
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -STA -File "%~dp0TextExpander.ps1"
