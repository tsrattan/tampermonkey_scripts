# Optional Windows verification. Uses temporary copies, never your live snippets.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$script = [IO.File]::ReadAllText((Join-Path $root 'TextExpander.ps1'))
$start = $script.IndexOf("`$source = @'") + 12
$end = $script.IndexOf("`n'@", $start)
$source = $script.Substring($start, $end - $start)
Add-Type -TypeDefinition $source -ReferencedAssemblies System.Windows.Forms, System.Drawing, System.Core -Language CSharp -IgnoreWarnings
$temp = Join-Path ([IO.Path]::GetTempPath()) ('PortableExpanderTest-' + [Guid]::NewGuid().ToString('N'))
function Assert($ok, $message) { if (-not $ok) { throw $message } }
try {
    [IO.Directory]::CreateDirectory((Join-Path $temp 'match')) | Out-Null
    Copy-Item -LiteralPath (Join-Path $root 'match/base.yml') -Destination (Join-Path $temp 'match/base.yml')
    $store = New-Object PortableExpander.SnippetStore($temp)
    $store.Load()
    $original = [IO.File]::ReadAllText((Join-Path $temp 'match/base.yml'))
    $initial = $store.Items.Count
    Assert ($initial -gt 0) 'No snippets found'
    Assert ($store.Warnings.Count -eq 0) 'Source parse warnings'
    $advanced = @($store.Items | Where-Object { $_.Trigger -eq 'date..' })[0]
    Assert (-not $advanced.Basic) 'Date variables must remain protected'
    $text = "Unicode: café 日本語`nQuotes: `"test`" and \\path`n`nLast line"
    $store.Save($null, ':manager-test', $text, 'Test', $true, 'Work', $false)
    $item = @($store.Items | Where-Object { $_.Trigger -eq ':manager-test' })[0]
    Assert ($item.Text -ceq $text) 'Text did not round trip'
    Assert ($store.Items.Count -eq ($initial + 1)) 'Add failed'
    $store.Save($item, $item.Trigger, $item.Text, $item.Label, $false, '', $false)
    $lib = New-Object PortableExpander.Library($temp); $lib.Load()
    Assert (@($lib.Matches | Where-Object { $_.Triggers.Contains(':manager-test') }).Count -eq 0) 'Disabled snippet still loaded'
    $item = @($store.Items | Where-Object { $_.Trigger -eq ':manager-test' })[0]
    $store.Save($item, $item.Trigger, $item.Text, $item.Label, $true, '', $false)
    $lib = New-Object PortableExpander.Library($temp); $lib.Load()
    Assert (@($lib.Matches | Where-Object { $_.Triggers.Contains(':manager-test') }).Count -eq 1) 'Enable failed'
    $snapshot = $store.Backup()
    $item = @($store.Items | Where-Object { $_.Trigger -eq ':manager-test' })[0]
    $store.Save($item, '', '', '', $false, '', $true)
    Assert ($store.Items.Count -eq $initial) 'Delete failed'
    $store.Restore($snapshot)
    Assert ($store.Items.Count -eq ($initial + 1)) 'Restore failed'
    Assert ([IO.File]::ReadAllText((Join-Path $temp 'match/base.yml')) -ceq $original) 'Existing source changed unexpectedly'
    $item = @($store.Items | Where-Object { $_.Trigger -eq 'codcp..' })[0]
    Assert ($item.Basic) 'Multiline snippet should be editable'
    $before = $item.Source
    $store.Save($item, $item.Trigger, "Updated`nmultiline", $item.Label, $true, '', $false)
    $after = [IO.File]::ReadAllText($item.Path)
    Assert ($after.StartsWith($before.Substring(0, $item.Start))) 'Text before edited snippet changed'
    Assert ($after.EndsWith($before.Substring($item.Start + $item.Length))) 'Text after edited snippet changed'
    $item = @($store.Items | Where-Object { $_.Trigger -eq 'shell..' })[0]
    [IO.File]::AppendAllText($item.Path, "`r`n# External change`r`n")
    $blocked = $false
    try { $store.Save($item, 'changed..', 'changed', '', $true, '', $false) } catch { $blocked = $true }
    Assert $blocked 'External-edit conflict was not blocked'
    Write-Host 'PASS: compile, load, text round trip, add, disable, enable, delete, backup/restore, source preservation and conflict detection.' -ForegroundColor Green
}
finally { if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Recurse -Force } }
