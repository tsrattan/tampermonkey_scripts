﻿# =====================================================================
#  Portable Text Expander - an espanso-compatible text expander for Windows
#  No install, no admin rights. Uses the PowerShell built into Windows.
#  Snippets live in the "match" folder as espanso YAML files.
#  Start it with "Start Text Expander.bat". See README.txt for help.
# =====================================================================
$ErrorActionPreference = 'Stop'
$scriptPath = $MyInvocation.MyCommand.Path
$folder     = Split-Path -Parent $scriptPath
$utf8       = New-Object System.Text.UTF8Encoding($false)

$starterMatch = @'
# espanso match file - edit and save, changes apply in about 2 seconds.
# Docs: https://espanso.org/docs/
matches:
  - trigger: "date.."
    replace: "{{mydate}}"
    vars:
      - name: mydate
        type: date
        params:
          format: "%d/%m/%Y"

  - trigger: "ty.."
    replace: "Thank you for your help!"
'@

$starterConfig = @'
# Settings use the same names as espanso's config/default.yml, e.g.
#backend: auto
#clipboard_threshold: 100
#search_shortcut: ALT+SPACE
#undo_backspace: true
'@

$matchDir  = Join-Path $folder 'match'
$configDir = Join-Path $folder 'config'
if (-not (Test-Path -LiteralPath $matchDir)) {
    New-Item -ItemType Directory -Path $matchDir | Out-Null
    [System.IO.File]::WriteAllText((Join-Path $matchDir 'base.yml'), $starterMatch, $utf8)
}
if (-not (Test-Path -LiteralPath $configDir)) {
    New-Item -ItemType Directory -Path $configDir | Out-Null
    [System.IO.File]::WriteAllText((Join-Path $configDir 'default.yml'), $starterConfig, $utf8)
}

$source = @'
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Microsoft.Win32;

namespace PortableExpander
{
    // =================================================================
    //  Mini YAML reader - covers what espanso files use: maps, lists,
    //  flow [..] {..}, quoted and plain text, | and > blocks, comments,
    //  &anchors / *aliases and << merges.
    // =================================================================
    public class YamlException : Exception
    {
        public YamlException(string m) : base(m) { }
    }

    public class Yaml
    {
        private readonly List<string> L;
        private int i;
        private readonly Dictionary<string, object> anchors = new Dictionary<string, object>();
        private string fs;
        private int fp;

        private Yaml(string text)
        {
            text = text.Replace("\r\n", "\n").Replace("\r", "\n").Replace("\t", "  ");
            if (text.Length > 0 && text[0] == '\uFEFF') text = text.Substring(1);
            L = new List<string>(text.Split('\n'));
        }

        public static object Parse(string text)
        {
            var p = new Yaml(text);
            object v = p.Node(0);
            p.Skip();
            if (p.i < p.L.Count) throw new YamlException("line " + (p.i + 1) + ": unexpected content");
            return v;
        }

        private static int Ind(string s)
        {
            int n = 0;
            while (n < s.Length && s[n] == ' ') n++;
            return n;
        }

        private static bool IsBlank(string s)
        {
            string t = s.Trim();
            return t.Length == 0 || t[0] == '#';
        }

        private static bool IsDash(string c)
        {
            return c.StartsWith("- ") || c.TrimEnd() == "-";
        }

        private static string StripComment(string s)
        {
            for (int k = 0; k < s.Length; k++)
                if (s[k] == '#' && (k == 0 || s[k - 1] == ' ')) return s.Substring(0, k).TrimEnd();
            return s.TrimEnd();
        }

        private static int FindQuoteEnd(string s, int start)
        {
            char q = s[start];
            int k = start + 1;
            while (k < s.Length)
            {
                char c = s[k];
                if (q == '"' && c == '\\') { k += 2; continue; }
                if (c == q)
                {
                    if (q == '\'' && k + 1 < s.Length && s[k + 1] == '\'') { k += 2; continue; }
                    return k;
                }
                k++;
            }
            return -1;
        }

        private static int MapColon(string c)
        {
            if (c.Length == 0 || "#[{|>%@`".IndexOf(c[0]) >= 0) return -1;
            if (c[0] == '-' && (c.Length == 1 || c[1] == ' ')) return -1;
            if (c[0] == '"' || c[0] == '\'')
            {
                int e = FindQuoteEnd(c, 0);
                if (e < 0) return -1;
                int k = e + 1;
                while (k < c.Length && c[k] == ' ') k++;
                if (k < c.Length && c[k] == ':' && (k + 1 == c.Length || c[k + 1] == ' ')) return k;
                return -1;
            }
            for (int k = 0; k < c.Length; k++)
            {
                if (c[k] == '#' && k > 0 && c[k - 1] == ' ') return -1;
                if (c[k] == ':' && (k + 1 == c.Length || c[k + 1] == ' ')) return k;
            }
            return -1;
        }

        private void Skip()
        {
            while (i < L.Count)
            {
                string l = L[i];
                string r = l.TrimEnd();
                if (IsBlank(l) || r == "---" || r == "..." || l.StartsWith("--- ") || l.StartsWith("%")) i++;
                else break;
            }
        }

        private object Node(int minInd)
        {
            Skip();
            if (i >= L.Count) return null;
            int n = Ind(L[i]);
            if (n < minInd) return null;
            string c = L[i].Substring(n);
            if (IsDash(c)) return Seq(n);
            if (MapColon(c) >= 0) return Map(n);
            return Inline(c, n, minInd - 1, false);
        }

        private List<object> Seq(int n)
        {
            var list = new List<object>();
            while (true)
            {
                Skip();
                if (i >= L.Count) break;
                string l = L[i];
                if (Ind(l) != n) break;
                string c = l.Substring(n);
                if (!IsDash(c)) break;
                string rest = c.Substring(1);
                int k = Ind(rest);
                rest = rest.Substring(k);
                list.Add(Inline(rest, n + 1 + k, n, false));
            }
            return list;
        }

        private Dictionary<string, object> Map(int n)
        {
            var map = new Dictionary<string, object>();
            while (true)
            {
                Skip();
                if (i >= L.Count) break;
                string l = L[i];
                int li = Ind(l);
                if (li < n) break;
                if (li > n) throw new YamlException("line " + (i + 1) + ": unexpected indentation");
                string c = l.Substring(n);
                int k = MapColon(c);
                if (k < 0)
                {
                    if (IsDash(c)) break;
                    throw new YamlException("line " + (i + 1) + ": expected 'key: value'");
                }
                string key = c.Substring(0, k).Trim();
                if (key.Length > 1 && (key[0] == '"' || key[0] == '\'')) key = Unquote(key);
                string rest = c.Substring(k + 1);
                int sp = Ind(rest);
                rest = rest.Substring(sp);
                object v = Inline(rest, n + k + 1 + sp, n, true);
                var merge = v as Dictionary<string, object>;
                if (key == "<<" && merge != null)
                {
                    foreach (var kv in merge) if (!map.ContainsKey(kv.Key)) map[kv.Key] = kv.Value;
                }
                else map[key] = v;
            }
            return map;
        }

        private static string Unquote(string t)
        {
            if (t[0] == '\'') return t.Substring(1, t.Length - 2).Replace("''", "'");
            return Unescape(t.Substring(1, t.Length - 2));
        }

        private static bool TryEscape(string t, ref int k, StringBuilder o)
        {
            // t[k] is a backslash with at least one char after it
            char d = t[k + 1];
            string simple = null;
            switch (d)
            {
                case 'n': simple = "\n"; break;
                case 't': simple = "\t"; break;
                case 'r': simple = "\r"; break;
                case '0': simple = "\0"; break;
                case 'a': simple = "\a"; break;
                case 'b': simple = "\b"; break;
                case 'e': simple = "\x1b"; break;
                case 'f': simple = "\f"; break;
                case 'v': simple = "\v"; break;
                case '"': simple = "\""; break;
                case '\\': simple = "\\"; break;
                case '/': simple = "/"; break;
                case ' ': simple = " "; break;
                case 'N': simple = "\u0085"; break;
                case '_': simple = "\u00A0"; break;
                case 'L': simple = "\u2028"; break;
                case 'P': simple = "\u2029"; break;
            }
            if (simple != null) { o.Append(simple); k += 2; return true; }
            int w = d == 'x' ? 2 : d == 'u' ? 4 : d == 'U' ? 8 : 0;
            if (w > 0 && k + 2 + w <= t.Length)
            {
                int code;
                if (int.TryParse(t.Substring(k + 2, w), System.Globalization.NumberStyles.HexNumber, null, out code))
                {
                    if (w == 4) o.Append((char)code);
                    else if (code <= 0x10FFFF && (code < 0xD800 || code > 0xDFFF)) o.Append(char.ConvertFromUtf32(code));
                    else return false;
                    k += 2 + w;
                    return true;
                }
            }
            return false;
        }

        private static string Unescape(string t)
        {
            var o = new StringBuilder();
            int k = 0;
            while (k < t.Length)
            {
                if (t[k] == '\\' && k + 1 < t.Length && TryEscape(t, ref k, o)) continue;
                o.Append(t[k]);
                k++;
            }
            return o.ToString();
        }

        private object Inline(string rest, int col, int parent, bool allowSameSeq)
        {
            string anchor = null;
            if (rest.StartsWith("&"))
            {
                int sp = rest.IndexOf(' ');
                anchor = sp < 0 ? rest.Substring(1) : rest.Substring(1, sp - 1);
                rest = sp < 0 ? "" : rest.Substring(sp + 1).TrimStart();
                col = L[i].Length - rest.Length;
            }
            object v = Inline2(rest, col, parent, allowSameSeq);
            if (anchor != null) anchors[anchor] = v;
            return v;
        }

        private object Inline2(string rest, int col, int parent, bool allowSameSeq)
        {
            if (rest.StartsWith("!"))
            {
                int sp = rest.IndexOf(' ');
                rest = sp < 0 ? "" : rest.Substring(sp + 1).TrimStart();
                col = L[i].Length - rest.Length;
            }
            if (rest.Length == 0 || rest[0] == '#')
            {
                i++;
                Skip();
                if (i < L.Count)
                {
                    int n = Ind(L[i]);
                    string c = L[i].Substring(n);
                    if (n > parent) return Node(parent + 1);
                    if (allowSameSeq && n == parent && IsDash(c)) return Seq(n);
                }
                return null;
            }
            if (rest[0] == '*')
            {
                string name = StripComment(rest.Substring(1)).Trim();
                i++;
                if (!anchors.ContainsKey(name)) throw new YamlException("line " + i + ": unknown alias *" + name);
                return anchors[name];
            }
            if (rest[0] == '|' || rest[0] == '>') return Block(StripComment(rest), parent);
            if (MapColon(rest) >= 0)
            {
                L[i] = new string(' ', col) + rest;
                return Map(col);
            }
            if (rest[0] == '"' || rest[0] == '\'') return Quoted(col);
            if (rest[0] == '[' || rest[0] == '{') return FlowBlock(col);
            if (IsDash(rest))
            {
                L[i] = new string(' ', col) + rest;
                return Seq(col);
            }
            // plain text, possibly continued on deeper lines
            var sb = new StringBuilder(StripComment(rest).Trim());
            i++;
            int empties = 0;
            while (i < L.Count)
            {
                string l = L[i];
                if (l.Trim().Length == 0) { empties++; i++; continue; }
                if (Ind(l) <= parent || l.Trim().StartsWith("#")) break;
                if (empties > 0) sb.Append('\n', empties); else sb.Append(' ');
                sb.Append(StripComment(l).Trim());
                empties = 0;
                i++;
            }
            return sb.ToString();
        }

        private string Block(string hdr, int parent)
        {
            char style = hdr[0];
            string chomp = "clip";
            int explicitInd = 0;
            for (int k = 1; k < hdr.Length; k++)
            {
                char ch = hdr[k];
                if (ch == '-') chomp = "strip";
                else if (ch == '+') chomp = "keep";
                else if (char.IsDigit(ch)) explicitInd = ch - '0';
            }
            i++;
            var lines = new List<string>();
            int cind = -1;
            if (explicitInd > 0) cind = (parent >= 0 ? parent : 0) + explicitInd;
            int j = i;
            while (j < L.Count)
            {
                string l = L[j];
                if (l.Trim().Length == 0) { lines.Add(""); j++; continue; }
                int n = Ind(l);
                if (cind < 0)
                {
                    if (n <= parent) break;
                    cind = n;
                }
                if (n < cind) break;
                lines.Add(l.Substring(cind));
                j++;
            }
            i = j;
            int last = lines.Count;
            while (last > 0 && lines[last - 1].Length == 0) last--;
            int trailing = lines.Count - last;
            if (last == 0) return chomp == "keep" ? new string('\n', trailing) : "";
            var o = new StringBuilder();
            if (style == '|')
            {
                for (int k = 0; k < last; k++)
                {
                    if (k > 0) o.Append('\n');
                    o.Append(lines[k]);
                }
            }
            else
            {
                int prev = 0; // 0 start, 1 text, 2 empty
                bool prevMore = false;
                for (int k = 0; k < last; k++)
                {
                    string l = lines[k];
                    if (l.Length == 0) { o.Append('\n'); prev = 2; continue; }
                    bool more = l[0] == ' ';
                    if (prev == 1) o.Append((more || prevMore) ? '\n' : ' ');
                    else if (prev == 2 && (more || prevMore)) o.Append('\n');
                    o.Append(l);
                    prev = 1;
                    prevMore = more;
                }
            }
            if (chomp == "clip") o.Append('\n');
            else if (chomp == "keep") o.Append('\n', 1 + trailing);
            return o.ToString();
        }

        private string Quoted(int col)
        {
            string l = L[i];
            char q = l[col];
            int k = col + 1;
            var o = new StringBuilder();
            while (true)
            {
                if (k >= l.Length)
                {
                    while (o.Length > 0 && o[o.Length - 1] == ' ') o.Length--;
                    i++;
                    int empt = 0;
                    while (i < L.Count && L[i].Trim().Length == 0) { empt++; i++; }
                    if (i >= L.Count) throw new YamlException("a quote (" + q + ") is never closed");
                    if (empt > 0) o.Append('\n', empt); else o.Append(' ');
                    l = L[i];
                    k = Ind(l);
                    continue;
                }
                char c = l[k];
                if (q == '"' && c == '\\')
                {
                    if (k + 1 >= l.Length)
                    {
                        i++;
                        if (i >= L.Count) throw new YamlException("a quote (\") is never closed");
                        l = L[i];
                        k = Ind(l);
                        continue;
                    }
                    if (TryEscape(l, ref k, o)) continue;
                    o.Append(l[k + 1]);
                    k += 2;
                    continue;
                }
                if (c == q)
                {
                    if (q == '\'' && k + 1 < l.Length && l[k + 1] == '\'') { o.Append('\''); k += 2; continue; }
                    i++;
                    return o.ToString();
                }
                o.Append(c);
                k++;
            }
        }

        private object FlowBlock(int col)
        {
            string line = L[i].Substring(col);
            int depth = 0;
            char q = '\0';
            var buf = new StringBuilder();
            while (true)
            {
                int k = 0;
                while (k < line.Length)
                {
                    char c = line[k];
                    if (q != '\0')
                    {
                        if (c == '\\' && q == '"' && k + 1 < line.Length) { buf.Append(c).Append(line[k + 1]); k += 2; continue; }
                        if (c == q) q = '\0';
                        buf.Append(c);
                        k++;
                        continue;
                    }
                    if (c == '"' || c == '\'') q = c;
                    else if (c == '#' && (k == 0 || line[k - 1] == ' ')) break;
                    else if (c == '[' || c == '{') depth++;
                    else if (c == ']' || c == '}') depth--;
                    buf.Append(c);
                    k++;
                }
                i++;
                if (depth <= 0) break;
                if (i >= L.Count) throw new YamlException("a bracket is never closed");
                buf.Append(' ');
                line = L[i];
            }
            fs = buf.ToString();
            fp = 0;
            return Flow();
        }

        private void Fws()
        {
            while (fp < fs.Length && (fs[fp] == ' ' || fs[fp] == '\n')) fp++;
        }

        private object Flow()
        {
            Fws();
            if (fp >= fs.Length) return null;
            char c = fs[fp];
            if (c == '[')
            {
                fp++;
                var list = new List<object>();
                while (true)
                {
                    Fws();
                    if (fp >= fs.Length) throw new YamlException("bad [list]");
                    if (fs[fp] == ']') { fp++; return list; }
                    list.Add(Flow());
                    Fws();
                    if (fp < fs.Length && fs[fp] == ',') fp++;
                    else if (fp < fs.Length && fs[fp] != ']') throw new YamlException("bad [list]");
                }
            }
            if (c == '{')
            {
                fp++;
                var map = new Dictionary<string, object>();
                while (true)
                {
                    Fws();
                    if (fp >= fs.Length) throw new YamlException("bad {map}");
                    if (fs[fp] == '}') { fp++; return map; }
                    string key = Convert.ToString(FlowScalar(true));
                    Fws();
                    object v = null;
                    if (fp < fs.Length && fs[fp] == ':') { fp++; v = Flow(); }
                    map[key] = v;
                    Fws();
                    if (fp < fs.Length && fs[fp] == ',') fp++;
                    else if (fp < fs.Length && fs[fp] != '}') throw new YamlException("bad {map}");
                }
            }
            return FlowScalar(false);
        }

        private object FlowScalar(bool isKey)
        {
            if (fs[fp] == '"' || fs[fp] == '\'')
            {
                int e = FindQuoteEnd(fs, fp);
                if (e < 0) throw new YamlException("a quote is never closed");
                string t = fs.Substring(fp, e - fp + 1);
                fp = e + 1;
                return Unquote(t);
            }
            int st = fp;
            if (fs[fp] == '*' && !isKey)
            {
                while (fp < fs.Length && ",]} ".IndexOf(fs[fp]) < 0) fp++;
                string name = fs.Substring(st + 1, fp - st - 1);
                if (!anchors.ContainsKey(name)) throw new YamlException("unknown alias *" + name);
                return anchors[name];
            }
            while (fp < fs.Length)
            {
                char c = fs[fp];
                if (c == ',' || c == ']' || c == '}') break;
                if (c == ':' && (fp + 1 >= fs.Length || " ,]}".IndexOf(fs[fp + 1]) >= 0)) break;
                fp++;
            }
            return fs.Substring(st, fp - st).Trim();
        }
    }
    // =================================================================
    //  Windows helpers
    // =================================================================
    public static class Native
    {
        public delegate IntPtr HookProc(int nCode, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll", SetLastError = true)] public static extern IntPtr SetWindowsHookEx(int idHook, HookProc fn, IntPtr hMod, uint threadId);
        [DllImport("user32.dll")] public static extern bool UnhookWindowsHookEx(IntPtr h);
        [DllImport("user32.dll")] public static extern IntPtr CallNextHookEx(IntPtr h, int n, IntPtr w, IntPtr l);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] public static extern IntPtr GetModuleHandle(string name);
        [DllImport("user32.dll")] public static extern short GetAsyncKeyState(int vk);
        [DllImport("user32.dll")] public static extern short GetKeyState(int vk);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int ToUnicodeEx(uint vk, uint scan, byte[] state, StringBuilder buf, int cch, uint flags, IntPtr hkl);
        [DllImport("user32.dll")] public static extern IntPtr GetKeyboardLayout(uint thread);
        [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
        [DllImport("user32.dll", SetLastError = true)] public static extern uint SendInput(uint n, INPUT[] inputs, int size);
        [DllImport("user32.dll")] public static extern uint MapVirtualKey(uint code, uint mapType);
        [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
        [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
        [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a, uint b, bool attach);
        [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
        [DllImport("kernel32.dll")] public static extern IntPtr OpenProcess(uint access, bool inherit, uint pid);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] public static extern bool QueryFullProcessImageName(IntPtr h, uint flags, StringBuilder sb, ref uint size);
        [DllImport("kernel32.dll")] public static extern bool CloseHandle(IntPtr h);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder sb, int max);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetClassName(IntPtr h, StringBuilder sb, int max);

        [StructLayout(LayoutKind.Sequential)] public struct KBDLLHOOKSTRUCT { public uint vkCode; public uint scanCode; public uint flags; public uint time; public IntPtr extra; }
        [StructLayout(LayoutKind.Sequential)] public struct KEYBDINPUT { public ushort wVk; public ushort wScan; public uint dwFlags; public uint time; public IntPtr dwExtraInfo; }
        [StructLayout(LayoutKind.Sequential)] public struct MOUSEINPUT { public int dx; public int dy; public uint mouseData; public uint dwFlags; public uint time; public IntPtr dwExtraInfo; }
        [StructLayout(LayoutKind.Explicit)] public struct InputUnion { [FieldOffset(0)] public MOUSEINPUT mi; [FieldOffset(0)] public KEYBDINPUT ki; }
        [StructLayout(LayoutKind.Sequential)] public struct INPUT { public uint type; public InputUnion u; }

        public static readonly IntPtr MAGIC = new IntPtr(0x54455850); // marks our own keystrokes

        public static bool Down(int vk) { return (GetAsyncKeyState(vk) & 0x8000) != 0; }

        public static void ForceForeground(IntPtr h)
        {
            if (h == IntPtr.Zero) return;
            uint pid;
            uint fgThread = GetWindowThreadProcessId(GetForegroundWindow(), out pid);
            uint me = GetCurrentThreadId();
            bool att = fgThread != 0 && fgThread != me && AttachThreadInput(me, fgThread, true);
            BringWindowToTop(h);
            SetForegroundWindow(h);
            if (att) AttachThreadInput(me, fgThread, false);
        }

        public static INPUT Key(ushort vk, bool up)
        {
            var i = new INPUT();
            i.type = 1;
            i.u.ki.wVk = vk;
            i.u.ki.wScan = (ushort)MapVirtualKey(vk, 0);
            bool ext = (vk >= 0x21 && vk <= 0x2E) || vk == 0x5B || vk == 0x5C;
            i.u.ki.dwFlags = (up ? 2u : 0u) | (ext ? 1u : 0u);
            i.u.ki.dwExtraInfo = MAGIC;
            return i;
        }

        public static void AddVk(List<INPUT> list, ushort vk)
        {
            list.Add(Key(vk, false));
            list.Add(Key(vk, true));
        }

        public static void AddUnicode(List<INPUT> list, char c)
        {
            for (int n = 0; n < 2; n++)
            {
                var i = new INPUT();
                i.type = 1;
                i.u.ki.wVk = 0;
                i.u.ki.wScan = c;
                i.u.ki.dwFlags = 4u | (n == 1 ? 2u : 0u);
                i.u.ki.dwExtraInfo = MAGIC;
                list.Add(i);
            }
        }

        public static void Send(List<INPUT> list)
        {
            if (list.Count == 0) return;
            SendInput((uint)list.Count, list.ToArray(), Marshal.SizeOf(typeof(INPUT)));
        }

        public static void PressCombo(List<ushort> keys)
        {
            var list = new List<INPUT>();
            foreach (ushort k in keys) list.Add(Key(k, false));
            for (int n = keys.Count - 1; n >= 0; n--) list.Add(Key(keys[n], true));
            Send(list);
        }

        public static string ProcessPath(IntPtr hwnd)
        {
            try
            {
                uint pid;
                GetWindowThreadProcessId(hwnd, out pid);
                IntPtr h = OpenProcess(0x1000, false, pid);
                if (h == IntPtr.Zero) return "";
                try
                {
                    var sb = new StringBuilder(1024);
                    uint size = 1024;
                    return QueryFullProcessImageName(h, 0, sb, ref size) ? sb.ToString() : "";
                }
                finally { CloseHandle(h); }
            }
            catch { return ""; }
        }

        public static string WindowTitle(IntPtr hwnd)
        {
            var sb = new StringBuilder(512);
            GetWindowText(hwnd, sb, 512);
            return sb.ToString();
        }

        public static string WindowClass(IntPtr hwnd)
        {
            var sb = new StringBuilder(256);
            GetClassName(hwnd, sb, 256);
            return sb.ToString();
        }

        // "CTRL+SHIFT+V" -> list of virtual keys (last one is the main key)
        public static List<ushort> ParseKeys(string spec)
        {
            var list = new List<ushort>();
            if (string.IsNullOrEmpty(spec)) return list;
            foreach (string raw in spec.Split('+'))
            {
                string t = raw.Trim().ToUpperInvariant();
                if (t.Length == 0) continue;
                ushort vk = 0;
                switch (t)
                {
                    case "CTRL": case "CONTROL": vk = 0x11; break;
                    case "SHIFT": vk = 0x10; break;
                    case "ALT": case "OPTION": vk = 0x12; break;
                    case "META": case "WIN": case "CMD": case "SUPER": vk = 0x5B; break;
                    case "SPACE": vk = 0x20; break;
                    case "ENTER": case "RETURN": vk = 0x0D; break;
                    case "TAB": vk = 0x09; break;
                    case "INSERT": case "INS": vk = 0x2D; break;
                    case "ESC": case "ESCAPE": vk = 0x1B; break;
                    default:
                        if (t.Length == 1 && ((t[0] >= 'A' && t[0] <= 'Z') || (t[0] >= '0' && t[0] <= '9'))) vk = t[0];
                        else if (t.Length >= 2 && t[0] == 'F')
                        {
                            int f;
                            if (int.TryParse(t.Substring(1), out f) && f >= 1 && f <= 24) vk = (ushort)(0x6F + f);
                        }
                        break;
                }
                if (vk == 0) return new List<ushort>();
                list.Add(vk);
            }
            return list;
        }
    }

    // =================================================================
    //  Small helpers for reading parsed YAML values
    // =================================================================
    public static class Y
    {
        public static Dictionary<string, object> D(object o) { return o as Dictionary<string, object>; }
        public static List<object> Lst(object o) { return o as List<object>; }

        public static object Get(Dictionary<string, object> d, string k)
        {
            object v;
            if (d != null && d.TryGetValue(k, out v)) return v;
            return null;
        }

        public static string S(Dictionary<string, object> d, string k)
        {
            object v = Get(d, k);
            if (v == null || v is Dictionary<string, object> || v is List<object>) return null;
            return Convert.ToString(v);
        }

        public static bool B(Dictionary<string, object> d, string k, bool def)
        {
            string s = S(d, k);
            if (s == null) return def;
            s = s.Trim().ToLowerInvariant();
            if (s == "true" || s == "yes" || s == "on" || s == "1") return true;
            if (s == "false" || s == "no" || s == "off" || s == "0") return false;
            return def;
        }

        public static int I(Dictionary<string, object> d, string k, int def)
        {
            string s = S(d, k);
            long n;
            if (s != null && long.TryParse(s.Trim(), out n)) return (int)Math.Max(int.MinValue, Math.Min(int.MaxValue, n));
            return def;
        }

        public static List<string> Strings(object o)
        {
            var r = new List<string>();
            var l = o as List<object>;
            if (l != null) { foreach (object x in l) if (x != null && !(x is Dictionary<string, object>) && !(x is List<object>)) r.Add(Convert.ToString(x)); }
            else if (o is string) r.Add((string)o);
            return r;
        }
    }

    // =================================================================
    //  Settings (config/default.yml and app-specific config/*.yml)
    // =================================================================
    public class Settings
    {
        public string Backend = "auto";
        public int ClipboardThreshold = 100;
        public string SearchShortcut = "ALT+SPACE";
        public bool UndoBackspace = true;
        public bool PreserveClipboard = true;
        public int RestoreClipboardDelay = 300;
        public string PasteShortcut = "CTRL+V";
        public bool Enable = true;
        public bool ShowNotifications = true;
        public string WordSeparators = null;

        public void Apply(Dictionary<string, object> d)
        {
            if (d == null) return;
            if (Y.Get(d, "backend") != null) Backend = Y.S(d, "backend").Trim().ToLowerInvariant();
            ClipboardThreshold = Y.I(d, "clipboard_threshold", ClipboardThreshold);
            if (Y.Get(d, "search_shortcut") != null) SearchShortcut = Y.S(d, "search_shortcut");
            UndoBackspace = Y.B(d, "undo_backspace", UndoBackspace);
            PreserveClipboard = Y.B(d, "preserve_clipboard", PreserveClipboard);
            RestoreClipboardDelay = Y.I(d, "restore_clipboard_delay", RestoreClipboardDelay);
            if (Y.Get(d, "paste_shortcut") != null) PasteShortcut = Y.S(d, "paste_shortcut");
            Enable = Y.B(d, "enable", Enable);
            ShowNotifications = Y.B(d, "show_notifications", ShowNotifications);
            object ws = Y.Get(d, "word_separators");
            if (ws != null) WordSeparators = string.Join("", Y.Strings(ws).ToArray());
        }

        public Settings Clone() { return (Settings)MemberwiseClone(); }
    }

    public class AppRule
    {
        public Regex Exec, Title, Class;
        public Dictionary<string, object> Data;
        public bool Matches(string exec, string title, string cls)
        {
            if (Exec == null && Title == null && Class == null) return false;
            if (Exec != null && !Exec.IsMatch(exec)) return false;
            if (Title != null && !Title.IsMatch(title)) return false;
            if (Class != null && !Class.IsMatch(cls)) return false;
            return true;
        }
    }

    // =================================================================
    //  A snippet ("match") in espanso format
    // =================================================================
    public class EMatch
    {
        public List<string> Triggers = new List<string>();
        public Regex Rx;
        public string Replace, Markdown, Html, ImagePath, Label, ForceMode, UpperStyle, File;
        public bool LeftWord, RightWord, Propagate;
        public List<object> Vars = new List<object>();
        public List<string> SearchTerms = new List<string>();

        public string TriggerText
        {
            get
            {
                if (Triggers.Count > 0) return string.Join("  ", Triggers.ToArray());
                if (Rx != null) return "regex: " + Rx.ToString();
                return "(search only)";
            }
        }

        public string Preview
        {
            get
            {
                string p = Label;
                if (string.IsNullOrEmpty(p)) p = Replace ?? Markdown ?? Html ?? (ImagePath != null ? "[image] " + ImagePath : "");
                p = p.Replace("\r", "").Replace("\n", " \u23CE ").Replace("\t", " ");
                if (p.Length > 160) p = p.Substring(0, 160) + "...";
                return p;
            }
        }
    }

    public class Hit
    {
        public EMatch M;
        public string Typed = "";
        public int Back;
        public string Swallowed = "";
        public string Suffix = "";
        public Dictionary<string, string> Groups;
    }

    public class RenderResult
    {
        public string Text, Html, Image;
    }
    // =================================================================
    //  Loads an espanso-style folder:  match\*.yml  and  config\*.yml
    // =================================================================
    public class Library
    {
        public List<EMatch> Matches = new List<EMatch>();
        public Dictionary<string, Dictionary<string, object>> Globals = new Dictionary<string, Dictionary<string, object>>();
        public Settings Config = new Settings();
        public List<AppRule> Rules = new List<AppRule>();
        public List<string> Errors = new List<string>();
        public int FileCount;

        private readonly string root;
        private readonly HashSet<string> loaded = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        public Library(string root) { this.root = root; }

        public static List<string> WatchedFiles(string root)
        {
            var list = new List<string>();
            foreach (string sub in new string[] { "match", "config" })
            {
                string dir = Path.Combine(root, sub);
                if (!Directory.Exists(dir)) continue;
                foreach (string f in Directory.GetFiles(dir, "*.*", SearchOption.AllDirectories))
                {
                    string ext = Path.GetExtension(f).ToLowerInvariant();
                    if (ext == ".yml" || ext == ".yaml") list.Add(f);
                }
            }
            list.Sort(StringComparer.OrdinalIgnoreCase);
            return list;
        }

        public void Load()
        {
            LoadConfig();
            string dir = Path.Combine(root, "match");
            if (!Directory.Exists(dir)) return;
            var files = new List<string>();
            foreach (string f in Directory.GetFiles(dir, "*.*", SearchOption.AllDirectories))
            {
                string ext = Path.GetExtension(f).ToLowerInvariant();
                if ((ext == ".yml" || ext == ".yaml") && !Path.GetFileName(f).StartsWith("_")) files.Add(f);
            }
            files.Sort(StringComparer.OrdinalIgnoreCase);
            foreach (string f in files) LoadMatchFile(f);
        }

        private string Short(string f)
        {
            return f.StartsWith(root, StringComparison.OrdinalIgnoreCase) ? f.Substring(root.Length).TrimStart('\\', '/') : f;
        }

        private object ReadYaml(string f)
        {
            try { return Yaml.Parse(System.IO.File.ReadAllText(f, Encoding.UTF8)); }
            catch (YamlException ex) { Errors.Add(Short(f) + ": " + ex.Message); }
            catch (Exception ex) { Errors.Add(Short(f) + ": " + ex.Message); }
            return null;
        }

        private void LoadConfig()
        {
            string dir = Path.Combine(root, "config");
            if (!Directory.Exists(dir)) return;
            string def = Path.Combine(dir, "default.yml");
            if (System.IO.File.Exists(def)) Config.Apply(Y.D(ReadYaml(def)));
            foreach (string f in Directory.GetFiles(dir, "*.yml"))
            {
                if (string.Equals(Path.GetFileName(f), "default.yml", StringComparison.OrdinalIgnoreCase)) continue;
                var d = Y.D(ReadYaml(f));
                if (d == null) continue;
                var r = new AppRule();
                r.Data = d;
                try
                {
                    string s;
                    if ((s = Y.S(d, "filter_exec")) != null) r.Exec = new Regex(s, RegexOptions.IgnoreCase);
                    if ((s = Y.S(d, "filter_title")) != null) r.Title = new Regex(s, RegexOptions.IgnoreCase);
                    if ((s = Y.S(d, "filter_class")) != null) r.Class = new Regex(s, RegexOptions.IgnoreCase);
                    Rules.Add(r);
                }
                catch (ArgumentException ex) { Errors.Add(Short(f) + ": bad filter - " + ex.Message); }
            }
        }

        private void LoadMatchFile(string f)
        {
            string full = Path.GetFullPath(f);
            if (!loaded.Add(full)) return;
            if (!System.IO.File.Exists(full)) { Errors.Add("import not found: " + Short(full)); return; }
            FileCount++;
            object doc = ReadYaml(full);
            var d = Y.D(doc);
            if (d == null)
            {
                // a bare list of matches is accepted too
                var bare = Y.Lst(doc);
                if (bare != null) AddMatches(bare, full);
                return;
            }

            foreach (string imp in Y.Strings(Y.Get(d, "imports")))
            {
                string p = imp.Replace("$CONFIG", root).Replace("%CONFIG%", root);
                if (!Path.IsPathRooted(p)) p = Path.Combine(Path.GetDirectoryName(full), p);
                LoadMatchFile(p);
            }

            var gv = Y.Lst(Y.Get(d, "global_vars"));
            if (gv != null)
                foreach (object o in gv)
                {
                    var v = Y.D(o);
                    string name = Y.S(v, "name");
                    if (!string.IsNullOrEmpty(name)) Globals[name] = v;
                }

            var ms = Y.Lst(Y.Get(d, "matches"));
            if (ms != null) AddMatches(ms, full);
        }

        private void AddMatches(List<object> ms, string file)
        {
            int n = 0;
            foreach (object o in ms)
            {
                n++;
                var d = Y.D(o);
                if (d == null) continue;
                if (!Y.B(d, "portable_enabled", true)) continue;
                try
                {
                    var m = new EMatch();
                    m.File = Short(file);
                    string t = Y.S(d, "trigger");
                    if (!string.IsNullOrEmpty(t)) m.Triggers.Add(t);
                    foreach (string x in Y.Strings(Y.Get(d, "triggers"))) if (x.Length > 0) m.Triggers.Add(x);
                    string rx = Y.S(d, "regex");
                    if (!string.IsNullOrEmpty(rx)) m.Rx = new Regex("(?:" + Regex.Replace(rx.Replace("(?P<", "(?<"), @"\(\?P=(\w+)\)", @"\k<$1>") + ")$");

                    m.Replace = Y.S(d, "replace");
                    m.Markdown = Y.S(d, "markdown");
                    m.Html = Y.S(d, "html");
                    m.ImagePath = Y.S(d, "image_path");
                    m.Label = Y.S(d, "label");
                    m.ForceMode = (Y.S(d, "force_mode") ?? (Y.B(d, "force_clipboard", false) ? "clipboard" : "")).Trim().ToLowerInvariant();
                    m.UpperStyle = (Y.S(d, "uppercase_style") ?? "capitalize").Trim().ToLowerInvariant();
                    bool word = Y.B(d, "word", false);
                    m.LeftWord = word || Y.B(d, "left_word", false);
                    m.RightWord = word || Y.B(d, "right_word", false);
                    m.Propagate = Y.B(d, "propagate_case", false);
                    m.SearchTerms = Y.Strings(Y.Get(d, "search_terms"));
                    var vars = Y.Lst(Y.Get(d, "vars"));
                    if (vars != null) m.Vars.AddRange(vars);

                    string form = Y.S(d, "form");
                    if (form != null)
                    {
                        var p = new Dictionary<string, object>();
                        p["layout"] = form;
                        object ff = Y.Get(d, "form_fields");
                        if (ff != null) p["fields"] = ff;
                        var fv = new Dictionary<string, object>();
                        fv["name"] = "form1";
                        fv["type"] = "form";
                        fv["params"] = p;
                        m.Vars.Insert(0, fv);
                        m.Replace = Regex.Replace(form, @"\[\[\s*([\w\-]+)\s*\]\]", "{{form1.$1}}");
                    }

                    if (m.Replace == null && m.Markdown == null && m.Html == null && m.ImagePath == null)
                    {
                        Errors.Add(m.File + ": snippet #" + n + " (" + m.TriggerText + ") has no replace, form, markdown, html or image_path");
                        continue;
                    }
                    if (m.Triggers.Count == 0 && m.Rx == null && string.IsNullOrEmpty(m.Label))
                    {
                        Errors.Add(m.File + ": snippet #" + n + " has no trigger");
                        continue;
                    }
                    Matches.Add(m);
                }
                catch (ArgumentException ex)
                {
                    Errors.Add(Short(file) + ": snippet #" + n + " has a bad regex - " + ex.Message);
                }
            }
        }
    }
    // =================================================================
    //  Turns a match into final text: variables, forms, dates, scripts
    // =================================================================
    public class Renderer
    {
        private readonly App app;
        private readonly Library lib;
        private readonly Dictionary<string, Dictionary<string, object>> defs = new Dictionary<string, Dictionary<string, object>>();
        private readonly Dictionary<string, object> vals = new Dictionary<string, object>();
        private readonly List<string> order = new List<string>();
        private readonly HashSet<string> busy = new HashSet<string>();
        private readonly int depth;
        public bool DialogShown;
        private static readonly Random Rnd = new Random();
        private static readonly Regex VarRx = new Regex(@"\{\{\s*([\w\-]+)(?:\.([\w\-]+))?\s*\}\}");

        public Renderer(App app, Library lib, int depth)
        {
            this.app = app;
            this.lib = lib;
            this.depth = depth;
        }

        public RenderResult Render(EMatch m, Dictionary<string, string> groups)
        {
            if (depth > 8) throw new InvalidOperationException("nested matches go too deep");
            foreach (var g in lib.Globals) defs[g.Key] = g.Value;
            var localOrder = new List<string>();
            foreach (object o in m.Vars)
            {
                var v = Y.D(o);
                string name = Y.S(v, "name");
                if (string.IsNullOrEmpty(name)) continue;
                defs[name] = v;
                localOrder.Add(name);
            }
            if (groups != null)
                foreach (var g in groups) { vals[g.Key] = g.Value; order.Add(g.Key); }

            foreach (string name in localOrder) Eval(name);

            var r = new RenderResult();
            if (m.ImagePath != null)
            {
                r.Image = Inject(m.ImagePath).Replace("$CONFIG", app.Root).Replace("%CONFIG%", app.Root);
                if (!Path.IsPathRooted(r.Image)) r.Image = Path.Combine(app.Root, r.Image);
            }
            else if (m.Html != null)
            {
                r.Html = Inject(m.Html);
                r.Text = HtmlToText(r.Html);
            }
            else if (m.Markdown != null)
            {
                string md = Inject(m.Markdown);
                r.Html = MarkdownToHtml(md);
                r.Text = md;
            }
            else r.Text = Inject(m.Replace ?? "");
            return r;
        }

        public string Inject(string s)
        {
            if (string.IsNullOrEmpty(s) || s.IndexOf("{{") < 0) return s;
            return VarRx.Replace(s, delegate (Match mm)
            {
                string name = mm.Groups[1].Value;
                if (!defs.ContainsKey(name) && !vals.ContainsKey(name)) return mm.Value;
                object v = Eval(name);
                var dict = v as Dictionary<string, string>;
                if (mm.Groups[2].Success)
                {
                    string fv;
                    if (dict != null && dict.TryGetValue(mm.Groups[2].Value, out fv)) return fv;
                    return "";
                }
                return v as string ?? "";
            });
        }

        private object Eval(string name)
        {
            object cached;
            if (vals.TryGetValue(name, out cached)) return cached;
            Dictionary<string, object> def;
            if (!defs.TryGetValue(name, out def)) return "";
            if (!busy.Add(name)) return ""; // circular reference
            object result;
            try { result = Compute(def); }
            finally { busy.Remove(name); }
            vals[name] = result;
            order.Add(name);
            return result;
        }

        private string P(Dictionary<string, object> p, string key)
        {
            string s = Y.S(p, key);
            return s == null ? null : Inject(s);
        }

        private object Compute(Dictionary<string, object> def)
        {
            string type = (Y.S(def, "type") ?? "").Trim().ToLowerInvariant();
            var p = Y.D(Y.Get(def, "params")) ?? new Dictionary<string, object>();
            switch (type)
            {
                case "echo":
                    return P(p, "echo") ?? "";

                case "date":
                    {
                        DateTime now = DateTime.Now;
                        string tz = Y.S(p, "tz");
                        if (tz != null && (tz.Equals("UTC", StringComparison.OrdinalIgnoreCase) || tz.Equals("Etc/UTC", StringComparison.OrdinalIgnoreCase))) now = DateTime.UtcNow;
                        else if (tz != null)
                        {
                            try { now = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow, tz); } catch { }
                        }
                        now = now.AddSeconds(Y.I(p, "offset", 0));
                        CultureInfo culture = CultureInfo.CurrentCulture;
                        string loc = Y.S(p, "locale");
                        if (!string.IsNullOrEmpty(loc)) { try { culture = new CultureInfo(loc.Replace('_', '-')); } catch { } }
                        return Strftime(now, Y.S(p, "format") ?? "%x", culture);
                    }

                case "clipboard":
                    try { return Clipboard.ContainsText() ? Clipboard.GetText() : ""; }
                    catch { return ""; }

                case "random":
                    {
                        var choices = Y.Strings(Y.Get(p, "choices"));
                        if (choices.Count == 0) return "";
                        lock (Rnd) return Inject(choices[Rnd.Next(choices.Count)]);
                    }

                case "choice":
                    {
                        var items = new List<KeyValuePair<string, string>>();
                        object values = Y.Get(p, "values");
                        var list = Y.Lst(values);
                        if (list != null)
                        {
                            foreach (object o in list)
                            {
                                var vd = Y.D(o);
                                if (vd != null)
                                {
                                    string label = Inject(Y.S(vd, "label") ?? Y.S(vd, "id") ?? "");
                                    items.Add(new KeyValuePair<string, string>(label, Inject(Y.S(vd, "id") ?? label)));
                                }
                                else if (o != null) { string s = Inject(Convert.ToString(o)); items.Add(new KeyValuePair<string, string>(s, s)); }
                            }
                        }
                        else if (values is string)
                        {
                            foreach (string s in SplitLines(Inject((string)values), true)) items.Add(new KeyValuePair<string, string>(s, s));
                        }
                        DialogShown = true;
                        string picked = Picker.Choose("Choose a value", items);
                        if (picked == null) throw new OperationCanceledException();
                        return picked;
                    }

                case "form":
                    {
                        DialogShown = true;
                        var res = FormDialog.Ask(Y.S(p, "layout") ?? "", Y.D(Y.Get(p, "fields")), this);
                        if (res == null) throw new OperationCanceledException();
                        return res;
                    }

                case "shell":
                    {
                        string cmd = P(p, "cmd") ?? "";
                        string shell = (Y.S(p, "shell") ?? "powershell").Trim().ToLowerInvariant();
                        string exe, args;
                        switch (shell)
                        {
                            case "cmd": exe = "cmd.exe"; args = "/S /C \"" + cmd + "\""; break;
                            case "pwsh": exe = "pwsh.exe"; args = PsArgs(cmd); break;
                            case "wsl": case "wsl2": exe = "wsl.exe"; args = "bash -c " + Q(cmd); break;
                            case "bash": case "sh": case "zsh": case "fish": case "nu": exe = shell; args = "-c " + Q(cmd); break;
                            default: exe = "powershell.exe"; args = PsArgs(cmd); break;
                        }
                        return Run(exe, args, Y.B(p, "trim", true));
                    }

                case "script":
                    {
                        var a = Y.Strings(Y.Get(p, "args"));
                        if (a.Count == 0) return "";
                        for (int k = 0; k < a.Count; k++) a[k] = ExpandPathVars(Inject(a[k]));
                        var sb = new StringBuilder();
                        for (int k = 1; k < a.Count; k++) { if (k > 1) sb.Append(' '); sb.Append(Q(a[k])); }
                        return Run(a[0], sb.ToString(), Y.B(p, "trim", true));
                    }

                case "match":
                    {
                        string trig = Y.S(p, "trigger");
                        foreach (EMatch other in lib.Matches)
                        {
                            if (!other.Triggers.Contains(trig)) continue;
                            var sub = new Renderer(app, lib, depth + 1);
                            RenderResult rr = sub.Render(other, null);
                            if (sub.DialogShown) DialogShown = true;
                            return rr.Text ?? "";
                        }
                        return "";
                    }

                default:
                    app.Log("Unknown variable type '" + type + "' in variable '" + Y.S(def, "name") + "'");
                    return "";
            }
        }

        public string ExpandPathVars(string s)
        {
            return s.Replace("%CONFIG%", app.Root).Replace("$CONFIG", app.Root)
                    .Replace("%HOME%", Environment.GetFolderPath(Environment.SpecialFolder.UserProfile))
                    .Replace("%PACKAGES%", Path.Combine(app.Root, "match\\packages"));
        }

        public static List<string> SplitLines(string s, bool trim)
        {
            var r = new List<string>();
            foreach (string l in s.Replace("\r", "").Split('\n'))
            {
                string x = trim ? l.Trim() : l;
                if (!trim || x.Length > 0) r.Add(x);
            }
            return r;
        }

        private static string PsArgs(string cmd)
        {
            string full = "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8\n" + cmd;
            return "-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand " + Convert.ToBase64String(Encoding.Unicode.GetBytes(full));
        }

        // quote one argument following the Windows command-line rules
        public static string Q(string a)
        {
            if (a.Length > 0 && a.IndexOfAny(new char[] { ' ', '\t', '"', '\n' }) < 0) return a;
            var sb = new StringBuilder("\"");
            int bs = 0;
            foreach (char c in a)
            {
                if (c == '\\') { bs++; continue; }
                if (c == '"') { sb.Append('\\', bs * 2 + 1); sb.Append('"'); bs = 0; continue; }
                sb.Append('\\', bs); bs = 0; sb.Append(c);
            }
            sb.Append('\\', bs * 2);
            sb.Append('"');
            return sb.ToString();
        }

        private string Run(string exe, string args, bool trim)
        {
            var psi = new ProcessStartInfo(exe, args);
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            psi.StandardOutputEncoding = Encoding.UTF8;
            psi.WorkingDirectory = app.Root;
            psi.EnvironmentVariables["CONFIG"] = app.Root;
            psi.EnvironmentVariables["ESPANSO_CONFIG"] = app.Root;
            foreach (string name in order)
            {
                object v;
                if (!vals.TryGetValue(name, out v)) continue;
                string key = "ESPANSO_" + name.ToUpperInvariant().Replace('-', '_');
                if (v is string) psi.EnvironmentVariables[key] = (string)v;
                var dict = v as Dictionary<string, string>;
                if (dict != null) foreach (var kv in dict) psi.EnvironmentVariables[key + "_" + kv.Key.ToUpperInvariant().Replace('-', '_')] = kv.Value;
            }
            try
            {
                using (var proc = Process.Start(psi))
                {
                    var outTask = proc.StandardOutput.ReadToEndAsync();
                    var errTask = proc.StandardError.ReadToEndAsync();
                    if (!proc.WaitForExit(30000))
                    {
                        try { proc.Kill(); } catch { }
                        app.Log("Command timed out after 30s: " + exe + " " + args);
                        return "";
                    }
                    string output = outTask.Result;
                    string err = errTask.Result;
                    if (!string.IsNullOrEmpty(err)) app.Log("Command wrote an error: " + exe + "\r\n" + err);
                    output = output.Replace("\r\n", "\n");
                    return trim ? output.Trim() : output;
                }
            }
            catch (Exception ex)
            {
                app.Log("Couldn't run " + exe + ": " + ex.Message);
                return "";
            }
        }

        // ---------- strftime (chrono style) ----------
        private static string Num(int v, int width, char pad, char defPad)
        {
            if (pad == '-') return v.ToString();
            char p = pad == '\0' ? defPad : (pad == '_' ? ' ' : '0');
            return v.ToString().PadLeft(width, p);
        }

        public static string Strftime(DateTime d, string f, CultureInfo c)
        {
            var dtf = c.DateTimeFormat;
            var sb = new StringBuilder();
            for (int i = 0; i < f.Length; i++)
            {
                char ch = f[i];
                if (ch != '%' || i + 1 >= f.Length) { sb.Append(ch); continue; }
                char k = f[++i];
                char pad = '\0';
                if ((k == '-' || k == '_' || k == '0') && i + 1 < f.Length) { pad = k; k = f[++i]; }
                int hour12 = d.Hour % 12 == 0 ? 12 : d.Hour % 12;
                switch (k)
                {
                    case 'Y': sb.Append(d.Year); break;
                    case 'C': sb.Append(Num(d.Year / 100, 2, pad, '0')); break;
                    case 'y': sb.Append(Num(d.Year % 100, 2, pad, '0')); break;
                    case 'm': sb.Append(Num(d.Month, 2, pad, '0')); break;
                    case 'b': case 'h': sb.Append(dtf.GetAbbreviatedMonthName(d.Month)); break;
                    case 'B': sb.Append(dtf.GetMonthName(d.Month)); break;
                    case 'd': sb.Append(Num(d.Day, 2, pad, '0')); break;
                    case 'e': sb.Append(Num(d.Day, 2, pad, ' ')); break;
                    case 'a': sb.Append(dtf.GetAbbreviatedDayName(d.DayOfWeek)); break;
                    case 'A': sb.Append(dtf.GetDayName(d.DayOfWeek)); break;
                    case 'w': sb.Append((int)d.DayOfWeek); break;
                    case 'u': sb.Append(d.DayOfWeek == DayOfWeek.Sunday ? 7 : (int)d.DayOfWeek); break;
                    case 'j': sb.Append(Num(d.DayOfYear, 3, pad, '0')); break;
                    case 'U': sb.Append(Num(CultureInfo.InvariantCulture.Calendar.GetWeekOfYear(d, CalendarWeekRule.FirstFullWeek, DayOfWeek.Sunday) % 53, 2, pad, '0')); break;
                    case 'W': sb.Append(Num(CultureInfo.InvariantCulture.Calendar.GetWeekOfYear(d, CalendarWeekRule.FirstFullWeek, DayOfWeek.Monday) % 53, 2, pad, '0')); break;
                    case 'V': sb.Append(Num(IsoWeek(d), 2, pad, '0')); break;
                    case 'G': sb.Append(IsoYear(d)); break;
                    case 'g': sb.Append(Num(IsoYear(d) % 100, 2, pad, '0')); break;
                    case 'H': sb.Append(Num(d.Hour, 2, pad, '0')); break;
                    case 'k': sb.Append(Num(d.Hour, 2, pad, ' ')); break;
                    case 'I': sb.Append(Num(hour12, 2, pad, '0')); break;
                    case 'l': sb.Append(Num(hour12, 2, pad, ' ')); break;
                    case 'M': sb.Append(Num(d.Minute, 2, pad, '0')); break;
                    case 'S': sb.Append(Num(d.Second, 2, pad, '0')); break;
                    case 'f': sb.Append((d.Ticks % TimeSpan.TicksPerSecond * 100).ToString("000000000")); break;
                    case 'p': sb.Append(d.Hour < 12 ? "AM" : "PM"); break;
                    case 'P': sb.Append(d.Hour < 12 ? "am" : "pm"); break;
                    case 'Z': case 'z':
                        {
                            TimeSpan off = TimeZoneInfo.Local.GetUtcOffset(d);
                            sb.Append(off < TimeSpan.Zero ? '-' : '+').Append(Math.Abs(off.Hours).ToString("00")).Append(Math.Abs(off.Minutes).ToString("00"));
                            break;
                        }
                    case 's': sb.Append((long)(d.ToUniversalTime() - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalSeconds); break;
                    case 'D': sb.Append(Strftime(d, "%m/%d/%y", c)); break;
                    case 'F': sb.Append(Strftime(d, "%Y-%m-%d", c)); break;
                    case 'v': sb.Append(Strftime(d, "%e-%b-%Y", c)); break;
                    case 'T': sb.Append(Strftime(d, "%H:%M:%S", c)); break;
                    case 'R': sb.Append(Strftime(d, "%H:%M", c)); break;
                    case 'r': sb.Append(Strftime(d, "%I:%M:%S %p", c)); break;
                    case 'x': sb.Append(d.ToString(dtf.ShortDatePattern, c)); break;
                    case 'X': sb.Append(d.ToString(dtf.LongTimePattern, c)); break;
                    case 'c': sb.Append(d.ToString(dtf.FullDateTimePattern, c)); break;
                    case 'n': sb.Append('\n'); break;
                    case 't': sb.Append('\t'); break;
                    case '%': sb.Append('%'); break;
                    default: sb.Append('%').Append(k); break;
                }
            }
            return sb.ToString();
        }

        private static int IsoWeek(DateTime d)
        {
            DayOfWeek day = CultureInfo.InvariantCulture.Calendar.GetDayOfWeek(d);
            if (day >= DayOfWeek.Monday && day <= DayOfWeek.Wednesday) d = d.AddDays(3);
            return CultureInfo.InvariantCulture.Calendar.GetWeekOfYear(d, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);
        }

        private static int IsoYear(DateTime d)
        {
            int w = IsoWeek(d);
            if (w >= 52 && d.Month == 1) return d.Year - 1;
            if (w == 1 && d.Month == 12) return d.Year + 1;
            return d.Year;
        }

        // ---------- rich text ----------
        public static string HtmlToText(string html)
        {
            string s = Regex.Replace(html, @"<\s*br\s*/?\s*>", "\n", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"</\s*(p|div|li|h[1-6]|tr)\s*>", "\n", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"<[^>]*>", "");
            return System.Net.WebUtility.HtmlDecode(s).Trim('\n');
        }

        public static string MarkdownToHtml(string md)
        {
            var o = new StringBuilder();
            bool inList = false;
            var lines = md.Replace("\r", "").TrimEnd('\n').Split('\n');
            for (int n = 0; n < lines.Length; n++)
            {
                string line = lines[n];
                Match h = Regex.Match(line, @"^(#{1,6})\s+(.*)$");
                Match li = Regex.Match(line, @"^\s*[-*+]\s+(.*)$");
                if (li.Success)
                {
                    if (!inList) { o.Append("<ul>"); inList = true; }
                    o.Append("<li>").Append(Inline(li.Groups[1].Value)).Append("</li>");
                    continue;
                }
                if (inList) { o.Append("</ul>"); inList = false; }
                if (h.Success)
                {
                    int lvl = h.Groups[1].Value.Length;
                    o.Append("<h" + lvl + ">").Append(Inline(h.Groups[2].Value)).Append("</h" + lvl + ">");
                    continue;
                }
                o.Append(Inline(line));
                if (n < lines.Length - 1) o.Append("<br>");
            }
            if (inList) o.Append("</ul>");
            return o.ToString();
        }

        private static string Inline(string s)
        {
            s = System.Net.WebUtility.HtmlEncode(s);
            s = Regex.Replace(s, @"`([^`]+)`", "<code>$1</code>");
            s = Regex.Replace(s, @"\*\*(.+?)\*\*|__(.+?)__", "<b>$1$2</b>");
            s = Regex.Replace(s, @"(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])|(?<![\w_])_(?!\s)(.+?)(?<!\s)_(?![\w_])", "<i>$1$2</i>");
            s = Regex.Replace(s, @"~~(.+?)~~", "<s>$1</s>");
            s = Regex.Replace(s, @"\[([^\]]+)\]\(([^)\s]+)\)", "<a href=\"$2\">$1</a>");
            return s;
        }
    }
    // =================================================================
    //  Pop-up pickers and forms
    // =================================================================
    public class PickItem
    {
        public string Label, Search;
        public object Value;
        public override string ToString() { return Label; }
    }

    public class Picker : Form
    {
        private readonly TextBox box = new TextBox();
        private readonly ListBox list = new ListBox();
        private readonly List<PickItem> all;
        public object Result;

        public Picker(string title, List<PickItem> items)
        {
            all = items;
            Text = title;
            Width = 620;
            Height = 420;
            StartPosition = FormStartPosition.CenterScreen;
            TopMost = true;
            ShowInTaskbar = true;
            MinimizeBox = false;
            MaximizeBox = false;
            KeyPreview = true;
            Font = new Font("Segoe UI", 10f);

            box.Dock = DockStyle.Top;
            list.Dock = DockStyle.Fill;
            list.IntegralHeight = false;
            Controls.Add(list);
            Controls.Add(box);

            box.TextChanged += delegate { Filter(); };
            list.DoubleClick += delegate { Accept(); };
            KeyDown += delegate (object s, KeyEventArgs e)
            {
                if (e.KeyCode == Keys.Escape) { e.Handled = true; Close(); }
                else if (e.KeyCode == Keys.Enter) { e.Handled = true; e.SuppressKeyPress = true; Accept(); }
                else if (e.KeyCode == Keys.Down && box.Focused) { e.Handled = true; MoveSel(1); }
                else if (e.KeyCode == Keys.Up && box.Focused) { e.Handled = true; MoveSel(-1); }
            };
            Shown += delegate { Native.ForceForeground(Handle); Activate(); box.Focus(); };
            Filter();
        }

        private void MoveSel(int d)
        {
            if (list.Items.Count == 0) return;
            int n = Math.Max(0, Math.Min(list.Items.Count - 1, list.SelectedIndex + d));
            list.SelectedIndex = n;
        }

        private void Filter()
        {
            string[] words = box.Text.ToLowerInvariant().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            list.BeginUpdate();
            list.Items.Clear();
            foreach (PickItem it in all)
            {
                bool ok = true;
                foreach (string w in words) if (it.Search.IndexOf(w, StringComparison.Ordinal) < 0) { ok = false; break; }
                if (ok) list.Items.Add(it);
            }
            list.EndUpdate();
            if (list.Items.Count > 0) list.SelectedIndex = 0;
        }

        private void Accept()
        {
            var it = list.SelectedItem as PickItem;
            if (it == null) return;
            Result = it.Value;
            Close();
        }

        public static object Pick(string title, List<PickItem> items)
        {
            using (var f = new Picker(title, items))
            {
                f.ShowDialog();
                return f.Result;
            }
        }

        public static string Choose(string title, List<KeyValuePair<string, string>> items)
        {
            var list = new List<PickItem>();
            foreach (var kv in items)
            {
                var it = new PickItem();
                it.Label = kv.Key.Replace("\n", " \u23CE ");
                it.Search = kv.Key.ToLowerInvariant();
                it.Value = kv.Value;
                list.Add(it);
            }
            return Pick(title, list) as string;
        }
    }

    public class FormDialog : Form
    {
        private readonly Dictionary<string, Control> fields = new Dictionary<string, Control>();
        private readonly Dictionary<string, string> separators = new Dictionary<string, string>();
        private bool ok;

        private FormDialog(string layout, Dictionary<string, object> conf, Renderer r)
        {
            Text = "Fill in the snippet";
            StartPosition = FormStartPosition.CenterScreen;
            TopMost = true;
            KeyPreview = true;
            AutoSize = true;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            MinimizeBox = false;
            MaximizeBox = false;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Font = new Font("Segoe UI", 10f);

            var outer = new FlowLayoutPanel();
            outer.FlowDirection = FlowDirection.TopDown;
            outer.AutoSize = true;
            outer.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            outer.Padding = new Padding(12);
            outer.MaximumSize = new Size(900, 0);
            Controls.Add(outer);

            Control first = null;
            foreach (string line in layout.Replace("\r", "").TrimEnd('\n').Split('\n'))
            {
                var row = new FlowLayoutPanel();
                row.FlowDirection = FlowDirection.LeftToRight;
                row.AutoSize = true;
                row.AutoSizeMode = AutoSizeMode.GrowAndShrink;
                row.WrapContents = true;
                row.MaximumSize = new Size(870, 0);
                row.Margin = new Padding(0, 2, 0, 2);
                var parts = Regex.Split(line, @"\[\[\s*([\w\-]+)\s*\]\]");
                bool alone = parts.Length == 3 && parts[0].Trim().Length == 0 && parts[2].Trim().Length == 0;
                for (int k = 0; k < parts.Length; k++)
                {
                    if (k % 2 == 0)
                    {
                        if (parts[k].Length == 0) continue;
                        var lbl = new Label();
                        lbl.Text = parts[k];
                        lbl.AutoSize = true;
                        lbl.UseMnemonic = false;
                        lbl.MaximumSize = new Size(860, 0);
                        lbl.Margin = new Padding(0, 6, 0, 0);
                        row.Controls.Add(lbl);
                        continue;
                    }
                    string name = parts[k];
                    if (fields.ContainsKey(name)) continue;
                    Control c = MakeField(name, Y.D(Y.Get(conf, name)), r, alone);
                    fields[name] = c;
                    row.Controls.Add(c);
                    if (first == null) first = c;
                }
                if (line.Length == 0) row.Height = 10;
                outer.Controls.Add(row);
            }

            var buttons = new FlowLayoutPanel();
            buttons.FlowDirection = FlowDirection.RightToLeft;
            buttons.AutoSize = true;
            buttons.Margin = new Padding(0, 10, 0, 0);
            var submit = new Button();
            submit.Text = "Submit (Ctrl+Enter)";
            submit.AutoSize = true;
            submit.Click += delegate { ok = true; Close(); };
            var cancel = new Button();
            cancel.Text = "Cancel";
            cancel.AutoSize = true;
            cancel.Click += delegate { Close(); };
            buttons.Controls.Add(cancel);
            buttons.Controls.Add(submit);
            outer.Controls.Add(buttons);

            KeyDown += delegate (object s, KeyEventArgs e)
            {
                if (e.KeyCode == Keys.Escape) { e.Handled = true; Close(); }
                else if (e.KeyCode == Keys.Enter && (e.Control || !(ActiveControl is TextBox && ((TextBox)ActiveControl).Multiline)))
                {
                    e.Handled = true; e.SuppressKeyPress = true; ok = true; Close();
                }
            };
            Shown += delegate { Native.ForceForeground(Handle); Activate(); if (first != null) first.Focus(); };
        }

        private Control MakeField(string name, Dictionary<string, object> c, Renderer r, bool alone)
        {
            string type = (Y.S(c, "type") ?? "text").Trim().ToLowerInvariant();
            string def = Y.S(c, "default");
            if (def != null) def = r.Inject(def);
            if (type == "choice" || type == "list")
            {
                var values = new List<string>();
                object v = Y.Get(c, "values");
                if (v is string) values = Renderer.SplitLines(r.Inject((string)v), Y.B(c, "trim_string_values", true));
                else foreach (string s in Y.Strings(v)) values.Add(r.Inject(s));
                if (type == "choice")
                {
                    var cb = new ComboBox();
                    cb.DropDownStyle = ComboBoxStyle.DropDownList;
                    cb.Width = 260;
                    foreach (string s in values) cb.Items.Add(s);
                    int idx = def != null ? values.IndexOf(def) : -1;
                    if (idx >= 0) cb.SelectedIndex = idx;
                    else if (cb.Items.Count > 0 && def == null) cb.SelectedIndex = 0;
                    return cb;
                }
                var lb = new ListBox();
                lb.SelectionMode = SelectionMode.MultiExtended;
                lb.Width = 260;
                lb.Height = Math.Min(160, Math.Max(60, values.Count * 20 + 6));
                foreach (string s in values) lb.Items.Add(s);
                int li = def != null ? values.IndexOf(def) : -1;
                if (li >= 0) lb.SelectedIndex = li;
                separators[name] = Y.S(c, "separator") ?? ", ";
                return lb;
            }
            var tb = new TextBox();
            bool multi = Y.B(c, "multiline", false);
            tb.Multiline = multi;
            if (multi)
            {
                tb.AcceptsReturn = true;
                tb.ScrollBars = ScrollBars.Vertical;
                tb.Height = 90;
                tb.Width = 520;
            }
            else tb.Width = alone ? 520 : 180;
            if (def != null) tb.Text = def.Replace("\r\n", "\n").Replace("\n", "\r\n");
            return tb;
        }

        private Dictionary<string, string> Values()
        {
            var d = new Dictionary<string, string>();
            foreach (var kv in fields)
            {
                var lb = kv.Value as ListBox;
                if (lb != null)
                {
                    var sel = new List<string>();
                    foreach (object o in lb.SelectedItems) sel.Add(Convert.ToString(o));
                    d[kv.Key] = string.Join(separators[kv.Key], sel.ToArray());
                }
                else if (kv.Value is ComboBox) d[kv.Key] = Convert.ToString(((ComboBox)kv.Value).SelectedItem ?? "");
                else d[kv.Key] = kv.Value.Text.Replace("\r\n", "\n");
            }
            return d;
        }

        public static Dictionary<string, string> Ask(string layout, Dictionary<string, object> conf, Renderer r)
        {
            using (var f = new FormDialog(layout, conf, r))
            {
                f.ShowDialog();
                return f.ok ? f.Values() : null;
            }
        }
    }
    // =================================================================
    //  The tray app: keyboard listener, matching and typing
    // =================================================================
    public class UndoInfo
    {
        public int Count;
        public string Retype;
    }

    public class App : ApplicationContext
    {
        const int WH_KEYBOARD_LL = 13, WH_MOUSE_LL = 14;
        const int WM_KEYDOWN = 0x100, WM_SYSKEYDOWN = 0x104;
        const ushort VK_BACK = 0x08, VK_TAB = 0x09, VK_RETURN = 0x0D, VK_LEFT = 0x25;
        const string RUN_KEY = @"Software\Microsoft\Windows\CurrentVersion\Run";
        const string RUN_NAME = "PortableTextExpander";

        public readonly string Root;
        private readonly string scriptPath, logFile;
        private volatile Library lib;
        private string signature = "";
        private readonly StringBuilder buffer = new StringBuilder();
        private IntPtr kbHook = IntPtr.Zero, msHook = IntPtr.Zero;
        private Native.HookProc kbProc, msProc;
        private volatile bool paused, sending;
        private volatile UndoInfo undo;
        private List<ushort> searchKeys = new List<ushort>();
        private NotifyIcon tray;
        private ToolStripMenuItem pauseItem, startupItem;
        private Icon iconOn, iconOff;
        private System.Windows.Forms.Timer watchTimer;

        public static void Start(string folder, string scriptPath)
        {
            bool created;
            using (var mtx = new System.Threading.Mutex(true, "Local\\PortableTextExpander", out created))
            {
                if (!created)
                {
                    MessageBox.Show("Portable Text Expander is already running.\r\nLook for its icon near the clock.", "Portable Text Expander");
                    return;
                }
                Application.EnableVisualStyles();
                Application.Run(new App(folder, scriptPath));
            }
        }

        public App(string folder, string scriptPath)
        {
            Root = folder;
            this.scriptPath = scriptPath;
            logFile = Path.Combine(folder, "expander.log");

            iconOn = MakeIcon(Color.FromArgb(0, 120, 212));
            iconOff = MakeIcon(Color.Gray);
            BuildTray();
            Reload(false);

            kbProc = KeyboardHook;
            msProc = MouseHook;
            InstallHooks();

            watchTimer = new System.Windows.Forms.Timer();
            watchTimer.Interval = 2000;
            watchTimer.Tick += delegate { CheckForChanges(); };
            watchTimer.Start();

            Notify("Portable Text Expander is running",
                lib.Matches.Count + " snippets loaded. Right-click the TE icon to edit, search or pause." +
                (lib.Errors.Count > 0 ? "\r\nSome files have problems - see 'Show snippet list'." : ""), ToolTipIcon.Info, true);
        }

        public void Log(string text)
        {
            try { System.IO.File.AppendAllText(logFile, DateTime.Now.ToString("s") + "  " + text + Environment.NewLine); } catch { }
        }

        private void Notify(string title, string text, ToolTipIcon icon, bool force)
        {
            if (tray == null) return;
            if (!force && lib != null && !lib.Config.ShowNotifications) return;
            tray.ShowBalloonTip(5000, title, text.Length > 250 ? text.Substring(0, 250) + "..." : text, icon);
        }

        // ---------------- Loading ----------------
        private static string Signature(string root)
        {
            var sb = new StringBuilder();
            foreach (string f in Library.WatchedFiles(root))
            {
                try
                {
                    var fi = new FileInfo(f);
                    sb.Append(f).Append('|').Append(fi.LastWriteTimeUtc.Ticks).Append('|').Append(fi.Length).Append('\n');
                }
                catch { }
            }
            return sb.ToString();
        }

        private void CheckForChanges()
        {
            try
            {
                if (Signature(Root) != signature) Reload(true);
            }
            catch (Exception ex) { Log(ex.ToString()); }
        }

        private void Reload(bool notify)
        {
            signature = Signature(Root);
            var l = new Library(Root);
            try { l.Load(); }
            catch (Exception ex) { l.Errors.Add(ex.Message); }
            lib = l;
            string sc = (l.Config.SearchShortcut ?? "").Trim();
            searchKeys = (sc.Length == 0 || sc.Equals("off", StringComparison.OrdinalIgnoreCase)) ? new List<ushort>() : Native.ParseKeys(sc);
            foreach (string e in l.Errors) Log("Snippet problem: " + e);
            UpdateTrayText();
            if (notify)
            {
                if (l.Errors.Count > 0)
                    Notify("Some snippets couldn't be read", string.Join("\r\n", l.Errors.GetRange(0, Math.Min(3, l.Errors.Count)).ToArray()), ToolTipIcon.Warning, true);
                else
                    Notify("Snippets reloaded", l.Matches.Count + " snippets from " + l.FileCount + " file(s).", ToolTipIcon.Info, false);
            }
        }

        private Settings SettingsFor(IntPtr hwnd)
        {
            Library l = lib;
            Settings s = l.Config.Clone();
            string exec = Native.ProcessPath(hwnd);
            // Windows Notepad can drop injected characters. Use clipboard paste
            // automatically there, without requiring a separate config file.
            // Explicit backend choices and app-specific rules remain available.
            if (string.Equals(Path.GetFileName(exec), "notepad.exe", StringComparison.OrdinalIgnoreCase))
            {
                if (s.Backend == "auto") s.Backend = "clipboard";
                s.RestoreClipboardDelay = Math.Max(s.RestoreClipboardDelay, 750);
            }
            if (l.Rules.Count == 0) return s;
            string title = Native.WindowTitle(hwnd), cls = Native.WindowClass(hwnd);
            foreach (AppRule r in l.Rules) if (r.Matches(exec, title, cls)) s.Apply(r.Data);
            return s;
        }

        // ---------------- Hooks ----------------
        private void InstallHooks()
        {
            RemoveHooks();
            IntPtr mod = Native.GetModuleHandle(null);
            kbHook = Native.SetWindowsHookEx(WH_KEYBOARD_LL, kbProc, mod, 0);
            msHook = Native.SetWindowsHookEx(WH_MOUSE_LL, msProc, mod, 0);
            if (kbHook == IntPtr.Zero) Log("Keyboard hook failed, error " + Marshal.GetLastWin32Error());
        }

        private void RemoveHooks()
        {
            if (kbHook != IntPtr.Zero) { Native.UnhookWindowsHookEx(kbHook); kbHook = IntPtr.Zero; }
            if (msHook != IntPtr.Zero) { Native.UnhookWindowsHookEx(msHook); msHook = IntPtr.Zero; }
        }

        private IntPtr MouseHook(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0)
            {
                int m = wParam.ToInt32();
                if (m == 0x201 || m == 0x204 || m == 0x207) { buffer.Length = 0; undo = null; }
            }
            return Native.CallNextHookEx(msHook, nCode, wParam, lParam);
        }

        private IntPtr KeyboardHook(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0 && !paused && !sending)
            {
                int msg = wParam.ToInt32();
                if (msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN)
                {
                    var k = (Native.KBDLLHOOKSTRUCT)Marshal.PtrToStructure(lParam, typeof(Native.KBDLLHOOKSTRUCT));
                    if (k.extra != Native.MAGIC)
                    {
                        try { if (HandleKey(k)) return new IntPtr(1); }
                        catch (Exception ex) { Log(ex.ToString()); }
                    }
                }
            }
            return Native.CallNextHookEx(kbHook, nCode, wParam, lParam);
        }

        private static bool IsModifier(uint vk)
        {
            return vk == 0x10 || vk == 0x11 || vk == 0x12 || (vk >= 0xA0 && vk <= 0xA5) || vk == 0x5B || vk == 0x5C || vk == 0x14 || vk == 0x90 || vk == 0x91;
        }

        private bool HandleKey(Native.KBDLLHOOKSTRUCT k)
        {
            uint vk = k.vkCode;
            if (IsModifier(vk)) return false;
            bool ctrl = Native.Down(0x11), alt = Native.Down(0x12), shift = Native.Down(0x10);
            bool win = Native.Down(0x5B) || Native.Down(0x5C);

            // search bar shortcut (ALT+SPACE by default)
            if (searchKeys.Count > 0 && vk == searchKeys[searchKeys.Count - 1]
                && ctrl == searchKeys.Contains(0x11) && alt == searchKeys.Contains(0x12)
                && shift == searchKeys.Contains(0x10) && win == searchKeys.Contains(0x5B))
            {
                buffer.Length = 0;
                undo = null;
                if (alt || win) Native.PressCombo(new List<ushort>(new ushort[] { 0xE8 })); // stops Alt/Win opening menus
                StartSearch();
                return true;
            }

            // backspace straight after an expansion = undo it
            UndoInfo u = undo;
            undo = null;
            if (vk == VK_BACK && u != null && !ctrl && !alt && !win)
            {
                buffer.Length = 0;
                StartUndo(u);
                return true;
            }

            if (win || (ctrl != alt)) { buffer.Length = 0; return false; } // a shortcut, not typing (Ctrl+Alt = AltGr is fine)
            if (vk == VK_BACK) { if (buffer.Length > 0) buffer.Length--; return false; }

            string ch = Translate(vk, k.scanCode, ctrl && alt);
            if (ch == null) return false; // dead key - wait for the next key
            if (ch == "\r") ch = "\n";
            if (ch.Length == 0 || (char.IsControl(ch[0]) && ch != "\n" && ch != "\t")) { buffer.Length = 0; return false; }

            buffer.Append(ch);
            if (buffer.Length > 300) buffer.Remove(0, buffer.Length - 150);

            List<Hit> hits = FindHits(buffer.ToString());
            if (hits.Count > 0)
            {
                IntPtr fg = Native.GetForegroundWindow();
                Library l = lib;
                if (!l.Config.Enable && l.Rules.Count == 0) return false;
                if (!SettingsFor(fg).Enable) return false;
                buffer.Length = 0;
                Fire(hits, fg, false);
                return true; // swallow the last key; we type everything ourselves
            }
            if (ch == "\n" || ch == "\t") buffer.Length = 0;
            return false;
        }

        private string Translate(uint vk, uint scan, bool altGr)
        {
            byte[] st = new byte[256];
            if (Native.Down(0x10)) st[0x10] = 0x80;
            if ((Native.GetKeyState(0x14) & 1) != 0) st[0x14] = 1;
            if (altGr) { st[0x11] = 0x80; st[0x12] = 0x80; }
            uint pid;
            IntPtr hkl = Native.GetKeyboardLayout(Native.GetWindowThreadProcessId(Native.GetForegroundWindow(), out pid));
            var sb = new StringBuilder(8);
            int r = Native.ToUnicodeEx(vk, scan, st, sb, 8, 4, hkl);
            if (r < 0) return null;
            if (r == 0) return "";
            return sb.ToString(0, Math.Min(r, sb.Length));
        }

        // ---------------- Matching ----------------
        private bool IsSep(char c)
        {
            string ws = lib.Config.WordSeparators;
            if (ws != null) return ws.IndexOf(c) >= 0;
            return char.IsWhiteSpace(c) || char.IsPunctuation(c) || char.IsSymbol(c);
        }

        private static int CaretLength(string s)
        {
            int n = 0;
            for (int i = 0; i < s.Length; i++) if (!char.IsLowSurrogate(s[i])) n++;
            return n;
        }

        private static string LastChar(string s)
        {
            if (s.Length >= 2 && char.IsLowSurrogate(s[s.Length - 1])) return s.Substring(s.Length - 2);
            return s.Length > 0 ? s.Substring(s.Length - 1) : "";
        }

        private Hit TryTrigger(EMatch m, string t, string b)
        {
            StringComparison cmp = m.Propagate ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal;
            var h = new Hit();
            h.M = m;
            if (m.RightWord)
            {
                if (b.Length < t.Length + 1) return null;
                char last = b[b.Length - 1];
                if (!IsSep(last)) return null;
                string before = b.Substring(0, b.Length - 1);
                if (!before.EndsWith(t, cmp)) return null;
                int start = before.Length - t.Length;
                if (m.LeftWord && start > 0 && !IsSep(before[start - 1])) return null;
                h.Typed = before.Substring(start);
                h.Back = CaretLength(h.Typed);
                h.Suffix = last.ToString();
                h.Swallowed = h.Suffix;
            }
            else
            {
                if (!b.EndsWith(t, cmp)) return null;
                int start = b.Length - t.Length;
                if (m.LeftWord && start > 0 && !IsSep(b[start - 1])) return null;
                h.Typed = b.Substring(start);
                h.Back = CaretLength(h.Typed) - 1;
                h.Swallowed = LastChar(h.Typed);
            }
            return h;
        }

        private List<Hit> FindHits(string b)
        {
            var hits = new List<Hit>();
            int best = 0;
            foreach (EMatch m in lib.Matches)
            {
                Hit found = null;
                foreach (string t in m.Triggers)
                {
                    Hit h = TryTrigger(m, t, b);
                    if (h != null && (found == null || h.Typed.Length > found.Typed.Length)) found = h;
                }
                if (found == null && m.Rx != null)
                {
                    Match rm = m.Rx.Match(b);
                    if (rm.Success && rm.Length > 0)
                    {
                        found = new Hit();
                        found.M = m;
                        found.Typed = rm.Value;
                        found.Back = CaretLength(rm.Value) - 1;
                        found.Swallowed = LastChar(rm.Value);
                        found.Groups = new Dictionary<string, string>();
                        foreach (string g in m.Rx.GetGroupNames())
                        {
                            int dummy;
                            if (int.TryParse(g, out dummy)) continue;
                            found.Groups[g] = rm.Groups[g].Value;
                        }
                    }
                }
                if (found == null) continue;
                int len = found.Typed.Length + found.Suffix.Length;
                if (len > best) { hits.Clear(); best = len; hits.Add(found); }
                else if (len == best && found.Back == hits[0].Back && found.Suffix == hits[0].Suffix) hits.Add(found);
            }
            return hits;
        }

        // ---------------- Expanding ----------------
        private void RunInBackground(System.Threading.ThreadStart work)
        {
            sending = true;
            var t = new System.Threading.Thread(delegate ()
            {
                try { work(); }
                catch (Exception ex) { Log(ex.ToString()); }
                finally { sending = false; }
            });
            t.SetApartmentState(System.Threading.ApartmentState.STA);
            t.IsBackground = true;
            t.Start();
        }

        private void Fire(List<Hit> hits, IntPtr hwnd, bool dialogAlready)
        {
            RunInBackground(delegate { Expand(hits, hwnd, dialogAlready); });
        }

        private void Expand(List<Hit> hits, IntPtr hwnd, bool dialog)
        {
            Hit h = hits[0];
            Settings st = SettingsFor(hwnd);
            try
            {
                if (hits.Count > 1)
                {
                    var items = new List<PickItem>();
                    for (int n = 0; n < hits.Count; n++)
                    {
                        var it = new PickItem();
                        it.Label = hits[n].M.Preview;
                        it.Search = (hits[n].M.Preview + " " + hits[n].M.File).ToLowerInvariant();
                        it.Value = n;
                        items.Add(it);
                    }
                    dialog = true;
                    object r = Picker.Pick("Choose a snippet for " + h.Typed, items);
                    if (r == null) throw new OperationCanceledException();
                    h = hits[(int)r];
                }

                var ren = new Renderer(this, lib, 0);
                RenderResult res;
                try { res = ren.Render(h.M, h.Groups); }
                finally { if (ren.DialogShown) dialog = true; }

                if (dialog) { Native.ForceForeground(hwnd); System.Threading.Thread.Sleep(150); }
                Output(h, res, st);
            }
            catch (OperationCanceledException)
            {
                if (dialog) { Native.ForceForeground(hwnd); System.Threading.Thread.Sleep(150); }
                if (h.Swallowed.Length > 0) TypeText(h.Swallowed);
            }
            catch (Exception ex)
            {
                Log("Expanding " + h.M.TriggerText + " failed: " + ex);
                Notify("Snippet failed", h.M.TriggerText + ": " + ex.Message, ToolTipIcon.Warning, true);
                if (dialog) { Native.ForceForeground(hwnd); System.Threading.Thread.Sleep(150); }
                if (h.Swallowed.Length > 0) TypeText(h.Swallowed);
            }
        }

        private static string Norm(string s) { return (s ?? "").Replace("\r\n", "\n").Replace("\r", "\n"); }

        private static string ApplyCase(string text, string typed, string style)
        {
            int letters = 0, upper = 0;
            bool firstUpper = false, seen = false;
            foreach (char c in typed)
            {
                if (!char.IsLetter(c)) continue;
                letters++;
                if (char.IsUpper(c)) upper++;
                if (!seen) { firstUpper = char.IsUpper(c); seen = true; }
            }
            if (letters == 0) return text;
            if (upper == letters && letters > 1) return text.ToUpper();
            if (!firstUpper) return text;
            if (style == "uppercase") return text.ToUpper();
            var sb = new StringBuilder(text);
            bool atWordStart = true;
            bool done = false;
            for (int i = 0; i < sb.Length; i++)
            {
                char c = sb[i];
                if (char.IsLetter(c))
                {
                    if (atWordStart && !done) sb[i] = char.ToUpper(c);
                    if (atWordStart && style != "capitalize_words") done = true;
                    atWordStart = false;
                }
                else if (char.IsWhiteSpace(c)) atWordStart = true;
            }
            return sb.ToString();
        }

        private void WaitModifiers()
        {
            for (int i = 0; i < 50 && (Native.Down(0x10) || Native.Down(0x11) || Native.Down(0x12) || Native.Down(0x5B) || Native.Down(0x5C)); i++)
                System.Threading.Thread.Sleep(20);
        }

        private void Output(Hit h, RenderResult res, Settings st)
        {
            WaitModifiers();
            var del = new List<Native.INPUT>();
            for (int i = 0; i < h.Back; i++) Native.AddVk(del, VK_BACK);

            if (res.Image != null)
            {
                if (!System.IO.File.Exists(res.Image))
                {
                    Notify("Image not found", res.Image, ToolTipIcon.Warning, true);
                    if (h.Swallowed.Length > 0) TypeText(h.Swallowed);
                    return;
                }
                Native.Send(del);
                System.Threading.Thread.Sleep(15);
                Bitmap bmp;
                using (var img = Image.FromFile(res.Image)) bmp = new Bitmap(img);
                var data = new DataObject();
                data.SetImage(bmp);
                PasteData(data, st);
                if (h.Suffix.Length > 0) TypeText(h.Suffix);
                return;
            }

            if (res.Html != null)
            {
                Native.Send(del);
                System.Threading.Thread.Sleep(15);
                var data = new DataObject();
                byte[] bytes = Encoding.UTF8.GetBytes(CfHtml(res.Html) + "\0");
                data.SetData(DataFormats.Html, new MemoryStream(bytes));
                data.SetData(DataFormats.UnicodeText, Norm(res.Text).Replace("\n", "\r\n"));
                PasteData(data, st);
                if (h.Suffix.Length > 0) TypeText(h.Suffix);
                return;
            }

            string text = Norm(res.Text);
            if (h.M.Propagate) text = ApplyCase(text, h.Typed, h.M.UpperStyle);
            text += Norm(h.Suffix);
            int lefts = 0;
            int cur = text.IndexOf("$|$");
            if (cur >= 0)
            {
                text = text.Remove(cur, 3).Replace("$|$", "");
                lefts = CaretLength(text.Substring(cur));
            }

            Native.Send(del);
            System.Threading.Thread.Sleep(15);

            string mode = h.M.ForceMode;
            bool clip = mode == "clipboard" ||
                (mode != "keys" && (st.Backend == "clipboard" || (st.Backend != "inject" && CaretLength(text) > st.ClipboardThreshold)));
            if (clip)
            {
                var data = new DataObject();
                data.SetData(DataFormats.UnicodeText, text.Replace("\n", "\r\n"));
                PasteData(data, st);
            }
            else TypeText(text);

            if (lefts > 0)
            {
                System.Threading.Thread.Sleep(15);
                var mv = new List<Native.INPUT>();
                for (int i = 0; i < lefts; i++) Native.AddVk(mv, VK_LEFT);
                Native.Send(mv);
            }
            else if (st.UndoBackspace && h.Typed.Length > 0)
            {
                var u = new UndoInfo();
                u.Count = CaretLength(text);
                u.Retype = h.Typed + h.Suffix;
                undo = u;
            }
        }

        private static string CfHtml(string frag)
        {
            const string pre = "<html><body>\r\n<!--StartFragment-->";
            const string post = "<!--EndFragment-->\r\n</body></html>";
            const string hdr = "Version:0.9\r\nStartHTML:{0:D10}\r\nEndHTML:{1:D10}\r\nStartFragment:{2:D10}\r\nEndFragment:{3:D10}\r\n";
            int hlen = string.Format(hdr, 0, 0, 0, 0).Length;
            var u = Encoding.UTF8;
            int startFrag = hlen + u.GetByteCount(pre);
            int endFrag = startFrag + u.GetByteCount(frag);
            int endHtml = endFrag + u.GetByteCount(post);
            return string.Format(hdr, hlen, endHtml, startFrag, endFrag) + pre + frag + post;
        }

        private void TypeText(string s)
        {
            var list = new List<Native.INPUT>();
            foreach (char c in s)
            {
                if (c == '\n') Native.AddVk(list, VK_RETURN);
                else if (c == '\t') Native.AddVk(list, VK_TAB);
                else if (c == '\r') continue;
                else Native.AddUnicode(list, c);
                if (list.Count >= 120) { Native.Send(list); list.Clear(); System.Threading.Thread.Sleep(5); }
            }
            Native.Send(list);
        }

        private void PasteData(DataObject data, Settings st)
        {
            DataObject saved = null;
            if (st.PreserveClipboard)
            {
                try
                {
                    IDataObject cur = Clipboard.GetDataObject();
                    if (cur != null)
                    {
                        saved = new DataObject();
                        foreach (string f in cur.GetFormats(false))
                        {
                            try { object d = cur.GetData(f); if (d != null) saved.SetData(f, d); } catch { }
                        }
                    }
                }
                catch { saved = null; }
            }

            Clipboard.SetDataObject(data, true, 10, 50);
            System.Threading.Thread.Sleep(40);
            List<ushort> keys = Native.ParseKeys(st.PasteShortcut);
            if (keys.Count == 0) keys = new List<ushort>(new ushort[] { 0x11, 0x56 });
            Native.PressCombo(keys);
            System.Threading.Thread.Sleep(Math.Max(100, st.RestoreClipboardDelay));
            if (saved != null) { try { Clipboard.SetDataObject(saved, true, 10, 50); } catch { } }
        }

        private void StartUndo(UndoInfo u)
        {
            RunInBackground(delegate
            {
                WaitModifiers();
                var del = new List<Native.INPUT>();
                for (int i = 0; i < u.Count; i++) Native.AddVk(del, VK_BACK);
                Native.Send(del);
                System.Threading.Thread.Sleep(15);
                TypeText(u.Retype);
            });
        }

        // ---------------- Search bar ----------------
        private List<PickItem> SearchItems()
        {
            var items = new List<PickItem>();
            foreach (EMatch m in lib.Matches)
            {
                var it = new PickItem();
                string trig = m.Triggers.Count > 0 ? m.Triggers[0] : "";
                it.Label = m.Preview + (trig.Length > 0 ? "      [" + trig + "]" : "");
                it.Search = (m.TriggerText + " " + (m.Label ?? "") + " " + string.Join(" ", m.SearchTerms.ToArray()) + " " + m.Preview).ToLowerInvariant();
                it.Value = m;
                items.Add(it);
            }
            return items;
        }

        private void StartSearch()
        {
            IntPtr hwnd = Native.GetForegroundWindow();
            RunInBackground(delegate
            {
                var m = Picker.Pick("Search snippets", SearchItems()) as EMatch;
                if (m == null) { Native.ForceForeground(hwnd); return; }
                var h = new Hit();
                h.M = m;
                h.Typed = "";
                Expand(new List<Hit>(new Hit[] { h }), hwnd, true);
            });
        }

        // ---------------- Tray ----------------
        private static Icon MakeIcon(Color back)
        {
            var bmp = new Bitmap(32, 32);
            using (var g = Graphics.FromImage(bmp))
            using (var br = new SolidBrush(back))
            using (var f = new Font("Segoe UI", 15, FontStyle.Bold, GraphicsUnit.Pixel))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
                g.FillEllipse(br, 0, 0, 31, 31);
                var sf = new StringFormat();
                sf.Alignment = StringAlignment.Center;
                sf.LineAlignment = StringAlignment.Center;
                g.DrawString("TE", f, Brushes.White, new RectangleF(0, 0, 32, 32), sf);
            }
            return Icon.FromHandle(bmp.GetHicon());
        }

        private void BuildTray()
        {
            var menu = new ContextMenuStrip();
            pauseItem = new ToolStripMenuItem("Pause expansions", null, delegate { SetPaused(!paused); });
            menu.Items.Add(pauseItem);
            menu.Items.Add(new ToolStripMenuItem("Search snippets...", null, delegate { StartSearch(); }));
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(new ToolStripMenuItem("Manage snippets...", null, delegate { ManageSnippets(); }));
            menu.Items.Add(new ToolStripMenuItem("Edit snippets...", null, delegate { OpenEditor(); }));
            menu.Items.Add(new ToolStripMenuItem("Show snippet list", null, delegate { ShowList(); }));
            menu.Items.Add(new ToolStripMenuItem("Reload snippets", null, delegate { Reload(true); InstallHooks(); }));
            menu.Items.Add(new ToolStripMenuItem("Open folder", null, delegate { Process.Start("explorer.exe", "\"" + Root + "\""); }));
            menu.Items.Add(new ToolStripMenuItem("Import my espanso snippets...", null, delegate { ImportEspanso(); }));
            menu.Items.Add(new ToolStripSeparator());
            startupItem = new ToolStripMenuItem("Start with Windows", null, delegate { ToggleStartup(); });
            startupItem.Checked = IsStartupEnabled();
            menu.Items.Add(startupItem);
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(new ToolStripMenuItem("Exit", null, delegate { ExitThread(); }));

            tray = new NotifyIcon();
            tray.Icon = iconOn;
            tray.Text = "Portable Text Expander";
            tray.ContextMenuStrip = menu;
            tray.DoubleClick += delegate { ManageSnippets(); };
            tray.Visible = true;
        }

        private void UpdateTrayText()
        {
            if (tray == null || lib == null) return;
            string t = "Portable Text Expander - " + lib.Matches.Count + " snippets" + (paused ? " (paused)" : "");
            tray.Text = t.Length > 63 ? t.Substring(0, 63) : t;
        }

        private void SetPaused(bool p)
        {
            paused = p;
            buffer.Length = 0;
            undo = null;
            pauseItem.Checked = p;
            tray.Icon = p ? iconOff : iconOn;
            UpdateTrayText();
        }

        private void ManageSnippets()
        {
            bool wasPaused = paused;
            SetPaused(true);
            watchTimer.Stop();
            try { using (var manager = new SnippetManager(Root)) manager.ShowDialog(); }
            catch (Exception ex) { Log(ex.ToString()); MessageBox.Show(ex.Message, "Snippet Manager"); }
            finally { Reload(false); SetPaused(wasPaused); watchTimer.Start(); }
        }

        private void OpenEditor()
        {
            try
            {
                string f = Path.Combine(Root, "match\\base.yml");
                if (System.IO.File.Exists(f)) Process.Start("notepad.exe", "\"" + f + "\"");
                else Process.Start("explorer.exe", "\"" + Path.Combine(Root, "match") + "\"");
            }
            catch (Exception ex) { Log(ex.ToString()); }
        }

        private void ShowList()
        {
            Library l = lib;
            var form = new Form();
            form.Text = "Portable Text Expander - " + l.Matches.Count + " snippets from " + l.FileCount + " file(s)";
            form.Size = new Size(860, 520);
            form.StartPosition = FormStartPosition.CenterScreen;
            form.Icon = iconOn;
            var lv = new ListView();
            lv.Dock = DockStyle.Fill;
            lv.View = View.Details;
            lv.FullRowSelect = true;
            lv.GridLines = true;
            lv.Columns.Add("Type this", 160);
            lv.Columns.Add("Expands to", 480);
            lv.Columns.Add("File", 180);
            foreach (EMatch m in l.Matches)
                lv.Items.Add(new ListViewItem(new string[] { m.TriggerText, m.Preview, m.File }));
            lv.Sorting = SortOrder.Ascending;

            if (l.Errors.Count > 0)
            {
                var err = new TextBox();
                err.Multiline = true;
                err.ReadOnly = true;
                err.ScrollBars = ScrollBars.Vertical;
                err.Dock = DockStyle.Top;
                err.Height = 90;
                err.ForeColor = Color.DarkRed;
                err.Text = "Problems found:\r\n" + string.Join("\r\n", l.Errors.ToArray());
                form.Controls.Add(lv);
                form.Controls.Add(err);
            }
            else form.Controls.Add(lv);

            var bar = new FlowLayoutPanel();
            bar.Dock = DockStyle.Bottom;
            bar.Height = 42;
            bar.FlowDirection = FlowDirection.RightToLeft;
            bar.Padding = new Padding(6);
            var edit = new Button();
            edit.Text = "Edit snippets";
            edit.AutoSize = true;
            edit.Click += delegate { OpenEditor(); form.Close(); };
            var folderBtn = new Button();
            folderBtn.Text = "Open folder";
            folderBtn.AutoSize = true;
            folderBtn.Click += delegate { Process.Start("explorer.exe", "\"" + Root + "\""); };
            bar.Controls.Add(edit);
            bar.Controls.Add(folderBtn);
            form.Controls.Add(bar);
            form.Show();
            form.Activate();
        }

        // ---------------- Import from an installed espanso ----------------
        private void ImportEspanso()
        {
            string home = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            string appdata = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string src = null;
            foreach (string c in new string[] { Path.Combine(appdata, "espanso"), Path.Combine(home, ".config\\espanso"), Path.Combine(home, ".espanso") })
                if (Directory.Exists(Path.Combine(c, "match"))) { src = c; break; }

            if (src == null)
            {
                using (var dlg = new FolderBrowserDialog())
                {
                    dlg.Description = "Couldn't find espanso on this PC. Pick your espanso folder (the one that contains the 'match' folder).";
                    if (dlg.ShowDialog() != DialogResult.OK) return;
                    src = dlg.SelectedPath;
                    if (!Directory.Exists(Path.Combine(src, "match")) && Path.GetFileName(src).Equals("match", StringComparison.OrdinalIgnoreCase))
                        src = Path.GetDirectoryName(src);
                    if (!Directory.Exists(Path.Combine(src, "match")))
                    {
                        MessageBox.Show("That folder doesn't contain a 'match' folder.", "Portable Text Expander");
                        return;
                    }
                }
            }

            if (MessageBox.Show("Copy your espanso snippets from:\r\n" + src + "\r\n\r\nYour current snippets will be backed up first.",
                "Import espanso snippets", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) != DialogResult.OK) return;

            try
            {
                string backup = Path.Combine(Root, "backup-" + DateTime.Now.ToString("yyyyMMdd-HHmmss"));
                foreach (string sub in new string[] { "match", "config" })
                {
                    string mine = Path.Combine(Root, sub);
                    if (Directory.Exists(mine)) CopyDir(mine, Path.Combine(backup, sub));
                }
                string myMatch = Path.Combine(Root, "match");
                if (Directory.Exists(myMatch)) Directory.Delete(myMatch, true);
                foreach (string sub in new string[] { "match", "config", "images", "scripts" })
                {
                    string from = Path.Combine(src, sub);
                    if (Directory.Exists(from)) CopyDir(from, Path.Combine(Root, sub));
                }
                Reload(true);
                MessageBox.Show("Imported " + lib.Matches.Count + " snippets.\r\nYour previous snippets are saved in:\r\n" + backup,
                    "Import espanso snippets");
            }
            catch (Exception ex)
            {
                Log(ex.ToString());
                MessageBox.Show("The import didn't finish: " + ex.Message, "Portable Text Expander");
            }
        }

        private static void CopyDir(string from, string to)
        {
            Directory.CreateDirectory(to);
            foreach (string f in Directory.GetFiles(from)) System.IO.File.Copy(f, Path.Combine(to, Path.GetFileName(f)), true);
            foreach (string d in Directory.GetDirectories(from)) CopyDir(d, Path.Combine(to, Path.GetFileName(d)));
        }

        // ---------------- Start with Windows ----------------
        private string LaunchCommand
        {
            get { return "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -STA -File \"" + scriptPath + "\""; }
        }

        private bool IsStartupEnabled()
        {
            try
            {
                using (var k = Registry.CurrentUser.OpenSubKey(RUN_KEY, false))
                    return k != null && k.GetValue(RUN_NAME) != null;
            }
            catch { return false; }
        }

        private void ToggleStartup()
        {
            try
            {
                bool on = IsStartupEnabled();
                using (var k = Registry.CurrentUser.OpenSubKey(RUN_KEY, true))
                {
                    if (on) k.DeleteValue(RUN_NAME, false);
                    else k.SetValue(RUN_NAME, LaunchCommand);
                }
            }
            catch (Exception ex) { Log(ex.ToString()); MessageBox.Show("Couldn't change the startup setting on this PC.", "Portable Text Expander"); }
            startupItem.Checked = IsStartupEnabled();
        }

        protected override void ExitThreadCore()
        {
            RemoveHooks();
            if (watchTimer != null) watchTimer.Stop();
            if (tray != null) { tray.Visible = false; tray.Dispose(); }
            base.ExitThreadCore();
        }
    }
}
namespace PortableExpander
{
    // Conservative source editing: unsupported YAML is never reserialized.
    public class ManagedSnippet
    {
        public string Path, Source, Raw, Trigger, Text, Label;
        public int Start, Length;
        public bool Basic, Enabled;
        public override string ToString() { return Trigger; }
    }

    public class SnippetStore
    {
        public readonly string Root;
        public readonly List<ManagedSnippet> Items = new List<ManagedSnippet>();
        public readonly List<string> Warnings = new List<string>();
        public SnippetStore(string root) { Root = root; }
        public void Load()
        {
            Items.Clear(); Warnings.Clear();
            foreach (string path in Directory.GetFiles(System.IO.Path.Combine(Root, "match"), "*.*", SearchOption.AllDirectories))
            {
                string ext = System.IO.Path.GetExtension(path).ToLowerInvariant();
                if (ext != ".yml" && ext != ".yaml") continue;
                try { Read(path); } catch (Exception ex) { Warnings.Add(System.IO.Path.GetFileName(path) + ": " + ex.Message); }
            }
        }
        private void Read(string path)
        {
            string source = File.ReadAllText(path, Encoding.UTF8);
            var doc = Y.D(Yaml.Parse(source));
            var nodes = doc == null ? Y.Lst(Yaml.Parse(source)) : Y.Lst(Y.Get(doc, "matches"));
            if (nodes == null) return;
            // Only a conventional block list is safe to splice. Anchors/aliases and
            // flow collections remain visible but read-only.
            var head = Regex.Match(source, @"(?m)^matches:[ \t]*(?:#[^\r\n]*)?\r?$\n?");
            int begin = head.Success ? head.Index + head.Length : 0;
            int end = source.Length;
            if (head.Success)
            {
                var next = Regex.Match(source.Substring(begin), @"(?m)^[^\s#\-][^\r\n]*:");
                if (next.Success) end = begin + next.Index;
            }
            string area = source.Substring(begin, end - begin);
            var first = Regex.Match(area, @"(?m)^( *)- +[A-Za-z_]+:");
            string indent = first.Success ? first.Groups[1].Value : "";
            var starts = Regex.Matches(area, @"(?m)^" + indent + @"- +[A-Za-z_]+:");
            bool safe = first.Success && starts.Count == nodes.Count && (head.Success || doc == null)
                && !Regex.IsMatch(source, @"(?:^|[\s:,\[])[:]?[*&][A-Za-z_]")
                && !source.Contains("\t") && !source.Contains("<<:");
            for (int i = 0; i < nodes.Count; i++)
            {
                var d = Y.D(nodes[i]); if (d == null) continue;
                var s = new ManagedSnippet(); s.Path = path; s.Source = source;
                s.Trigger = Y.S(d, "trigger") ?? string.Join(" / ", Y.Strings(Y.Get(d, "triggers")).ToArray());
                if (s.Trigger.Length == 0) s.Trigger = Y.S(d, "regex") ?? "(search only)";
                s.Text = Y.S(d, "replace") ?? Y.S(d, "form") ?? Y.S(d, "markdown") ?? Y.S(d, "html") ?? "[advanced snippet]";
                s.Label = Y.S(d, "label") ?? "";
                s.Enabled = Y.B(d, "portable_enabled", true);
                s.Basic = safe && Y.S(d, "trigger") != null && Y.S(d, "replace") != null;
                foreach (string key in d.Keys)
                    if (key != "trigger" && key != "replace" && key != "label" && key != "portable_enabled") s.Basic = false;
                if (safe)
                {
                    s.Start = begin + starts[i].Index;
                    int stop = i + 1 < starts.Count ? begin + starts[i + 1].Index : end;
                    s.Raw = source.Substring(s.Start, stop - s.Start);
                    // Leave trailing blank lines and comments with the surrounding file.
                    var trailing = Regex.Match(s.Raw, @"(?m)(?:^[ \t]*(?:#[^\r\n]*)?\r?\n)+\z");
                    if (trailing.Success) s.Raw = s.Raw.Substring(0, trailing.Index);
                    s.Length = s.Raw.Length;
                    // Inline/interior comments and unusual scalar syntax are protected.
                    if (s.Raw.Contains("#")) s.Basic = false;
                }
                Items.Add(s);
            }
        }
        public static string Quote(string value)
        {
            var b = new StringBuilder("\"");
            foreach (char c in value)
            {
                if (c == '\\') b.Append("\\\\"); else if (c == '"') b.Append("\\\"");
                else if (c == '\r') b.Append("\\r"); else if (c == '\n') b.Append("\\n");
                else if (c == '\t') b.Append("\\t"); else if (char.IsControl(c)) b.Append("\\u" + ((int)c).ToString("x4"));
                else b.Append(c);
            }
            return b.Append('"').ToString();
        }
        public static string Block(string trigger, string text, string label, bool enabled, string indent, string nl)
        {
            return indent + "- trigger: " + Quote(trigger) + nl + indent + "  replace: " + Quote(text) + nl
                + indent + "  label: " + Quote(label) + nl + indent + "  portable_enabled: " + (enabled ? "true" : "false") + nl;
        }
        public string Backup()
        {
            string path = System.IO.Path.Combine(Root, "backups", "snippets-" + DateTime.Now.ToString("yyyyMMdd-HHmmss-fff") + "-" + Guid.NewGuid().ToString("N").Substring(0, 6));
            CopyTree(System.IO.Path.Combine(Root, "match"), System.IO.Path.Combine(path, "match"));
            return path;
        }
        public static void CopyTree(string from, string to)
        {
            Directory.CreateDirectory(to);
            foreach (string file in Directory.GetFiles(from)) File.Copy(file, System.IO.Path.Combine(to, System.IO.Path.GetFileName(file)), false);
            foreach (string dir in Directory.GetDirectories(from))
            {
                if ((File.GetAttributes(dir) & FileAttributes.ReparsePoint) != 0) throw new IOException("Linked folders cannot be backed up.");
                CopyTree(dir, System.IO.Path.Combine(to, System.IO.Path.GetFileName(dir)));
            }
        }
        public void Save(ManagedSnippet item, string trigger, string text, string label, bool enabled, string category, bool delete)
        {
            string path, previous, updated;
            if (item != null)
            {
                if (!item.Basic) throw new InvalidOperationException("This snippet must be edited in its YAML file.");
                path = item.Path; previous = item.Source;
                if (File.ReadAllText(path, Encoding.UTF8) != previous) throw new IOException("This file changed outside the manager. Close this editor and click Refresh.");
                string indent = Regex.Match(item.Raw, @"^ *").Value;
                string nl = previous.Contains("\r\n") ? "\r\n" : "\n";
                updated = previous.Substring(0, item.Start) + (delete ? "" : Block(trigger, text, label, enabled, indent, nl)) + previous.Substring(item.Start + item.Length);
            }
            else
            {
                if (!Regex.IsMatch(category, @"^[A-Za-z0-9][A-Za-z0-9 _-]{0,39}$")) throw new ArgumentException("Category must be 1-40 letters, numbers, spaces, underscores or hyphens.");
                // Each new snippet gets its own file; existing category files are never rewritten.
                string dir = System.IO.Path.Combine(Root, "match", "managed", category);
                Directory.CreateDirectory(dir);
                path = System.IO.Path.Combine(dir, Guid.NewGuid().ToString("N") + ".yml");
                previous = null; updated = "matches:\r\n" + Block(trigger, text, label, enabled, "  ", "\r\n");
            }
            Yaml.Parse(updated);
            Backup();
            string temp = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                File.WriteAllText(temp, updated, new UTF8Encoding(false));
                if (previous != null)
                {
                    if (File.ReadAllText(path, Encoding.UTF8) != previous) throw new IOException("File changed while saving. Refresh and try again.");
                    File.Replace(temp, path, null);
                }
                else File.Move(temp, path);
            }
            finally { if (File.Exists(temp)) File.Delete(temp); }
            Load();
        }
        public void Restore(string backup)
        {
            string allowed = System.IO.Path.GetFullPath(System.IO.Path.Combine(Root, "backups")) + System.IO.Path.DirectorySeparatorChar;
            backup = System.IO.Path.GetFullPath(backup);
            if (!backup.StartsWith(allowed, StringComparison.OrdinalIgnoreCase) || !Directory.Exists(System.IO.Path.Combine(backup, "match")))
                throw new IOException("Choose a snippets backup folder inside this application's backups folder.");
            string staging = System.IO.Path.Combine(Root, "restore-" + Guid.NewGuid().ToString("N"));
            string live = System.IO.Path.Combine(Root, "match"), old = staging + "-old";
            try
            {
                CopyTree(System.IO.Path.Combine(backup, "match"), staging);
                foreach (string f in Directory.GetFiles(staging, "*.*", SearchOption.AllDirectories))
                    if (System.IO.Path.GetExtension(f).Equals(".yml", StringComparison.OrdinalIgnoreCase) || System.IO.Path.GetExtension(f).Equals(".yaml", StringComparison.OrdinalIgnoreCase)) Yaml.Parse(File.ReadAllText(f, Encoding.UTF8));
                Backup();
                Directory.Move(live, old);
                try { Directory.Move(staging, live); }
                catch { Directory.Move(old, live); throw; }
                Directory.Delete(old, true);
            }
            finally { if (Directory.Exists(staging)) Directory.Delete(staging, true); }
            Load();
        }
    }

    public class SnippetManager : Form
    {
        private readonly SnippetStore store;
        private readonly ListView list = new ListView();
        private readonly TextBox search = new TextBox();
        private readonly Label status = new Label();
        public SnippetManager(string root)
        {
            store = new SnippetStore(root);
            Text = "Portable Text Expander - Snippet Manager"; Size = new Size(1020, 650); MinimumSize = new Size(780, 470);
            StartPosition = FormStartPosition.CenterScreen; Font = new Font("Segoe UI", 10);
            var layout = new TableLayoutPanel(); layout.Dock = DockStyle.Fill; layout.RowCount = 4; layout.ColumnCount = 1; layout.Padding = new Padding(12);
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 38)); layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 46));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 55)); Controls.Add(layout);
            var searchRow = new TableLayoutPanel(); searchRow.ColumnCount = 2; searchRow.Dock = DockStyle.Fill;
            searchRow.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 65)); searchRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            searchRow.Controls.Add(new Label { Text = "Search", AutoSize = true }, 0, 0); search.Dock = DockStyle.Fill; searchRow.Controls.Add(search, 1, 0); layout.Controls.Add(searchRow, 0, 0);
            var bar = new FlowLayoutPanel(); bar.Dock = DockStyle.Fill;
            AddButton(bar, "New", delegate { Edit(null); }); AddButton(bar, "Edit", delegate { EditSelected(); });
            AddButton(bar, "Enable / Disable", delegate { Toggle(); }); AddButton(bar, "Delete", delegate { Delete(); });
            AddButton(bar, "Refresh", delegate { RefreshItems(); }); AddButton(bar, "Backup", delegate { Run(delegate { string p = store.Backup(); MessageBox.Show(this, "Backup saved:\r\n" + p, "Backup"); }); });
            AddButton(bar, "Restore", delegate { Restore(); }); AddButton(bar, "Open YAML", delegate { OpenYaml(); }); layout.Controls.Add(bar, 0, 1);
            list.Dock = DockStyle.Fill; list.View = View.Details; list.FullRowSelect = true; list.MultiSelect = false; list.HideSelection = false;
            list.Columns.Add("Trigger", 150); list.Columns.Add("Replacement / label", 365); list.Columns.Add("Status", 80); list.Columns.Add("Editing", 85); list.Columns.Add("File / category", 250);
            list.DoubleClick += delegate { EditSelected(); }; layout.Controls.Add(list, 0, 2);
            status.Dock = DockStyle.Fill; layout.Controls.Add(status, 0, 3);
            search.TextChanged += delegate { Filter(); }; RefreshItems();
        }
        private void AddButton(FlowLayoutPanel p, string text, Action action)
        { var b = new Button(); b.Text = text; b.AutoSize = true; b.Height = 32; b.Click += delegate { action(); }; p.Controls.Add(b); }
        private void Run(Action action) { try { action(); } catch (Exception ex) { MessageBox.Show(this, ex.Message, "Snippet Manager", MessageBoxButtons.OK, MessageBoxIcon.Warning); } }
        private ManagedSnippet Selected { get { return list.SelectedItems.Count == 0 ? null : list.SelectedItems[0].Tag as ManagedSnippet; } }
        private void RefreshItems() { Run(delegate { store.Load(); Filter(); }); }
        private void Filter()
        {
            string q = search.Text.Trim(); list.BeginUpdate(); list.Items.Clear();
            foreach (var s in store.Items)
            {
                string rel = s.Path.Substring(store.Root.Length).TrimStart('\\', '/');
                if ((s.Trigger + " " + s.Text + " " + s.Label + " " + rel).IndexOf(q, StringComparison.OrdinalIgnoreCase) < 0) continue;
                var row = new ListViewItem(new string[] { s.Trigger, (s.Label.Length > 0 ? s.Label + " - " : "") + s.Text.Replace("\r", "").Replace("\n", " / "), s.Enabled ? "Enabled" : "Disabled", s.Basic ? "Basic" : "Advanced", rel });
                row.Tag = s; if (!s.Enabled) row.ForeColor = Color.Gray; list.Items.Add(row);
            }
            list.EndUpdate(); status.Text = list.Items.Count + " of " + store.Items.Count + " snippets. Expansions are paused while this window is open.\r\n" +
                (store.Warnings.Count == 0 ? "Advanced snippets are protected; use Open YAML. Changes save with an automatic backup." : string.Join("; ", store.Warnings.ToArray()));
        }
        private bool CanEdit(ManagedSnippet s)
        {
            if (s == null) { MessageBox.Show(this, "Select a snippet first."); return false; }
            if (!s.Basic) { MessageBox.Show(this, "This snippet uses advanced YAML or comments. Use Open YAML to edit it without losing information."); return false; }
            return true;
        }
        private void EditSelected() { var s = Selected; if (CanEdit(s)) Edit(s); }
        private void Toggle() { var s = Selected; if (CanEdit(s)) Run(delegate { store.Save(s, s.Trigger, s.Text, s.Label, !s.Enabled, "", false); Filter(); }); }
        private void Delete()
        {
            var s = Selected; if (!CanEdit(s)) return;
            if (MessageBox.Show(this, "Delete " + s.Trigger + "? An automatic backup will be kept.", "Delete snippet", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                Run(delegate { store.Save(s, "", "", "", false, "", true); Filter(); });
        }
        private void OpenYaml() { var s = Selected; if (s != null) Run(delegate { Process.Start("notepad.exe", "\"" + s.Path + "\""); }); }
        private void Restore()
        {
            using (var dlg = new FolderBrowserDialog())
            {
                dlg.Description = "Choose a snippets backup folder (the folder containing match)."; dlg.SelectedPath = System.IO.Path.Combine(store.Root, "backups");
                if (dlg.ShowDialog(this) != DialogResult.OK) return;
                if (MessageBox.Show(this, "Replace the entire match folder with this backup? Current snippets will be backed up first.", "Restore snippets", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
                Run(delegate { store.Restore(dlg.SelectedPath); Filter(); });
            }
        }
        private void Edit(ManagedSnippet item)
        {
            using (var f = new Form())
            {
                f.Text = item == null ? "New snippet" : "Edit " + item.Trigger; f.Size = new Size(690, 560); f.MinimumSize = new Size(500, 440); f.StartPosition = FormStartPosition.CenterParent; f.Font = Font;
                var grid = new TableLayoutPanel(); grid.Dock = DockStyle.Fill; grid.Padding = new Padding(14); grid.ColumnCount = 2; grid.RowCount = 6;
                grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 100)); grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
                for (int i = 0; i < 3; i++) grid.RowStyles.Add(new RowStyle(SizeType.Absolute, 38));
                grid.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); grid.RowStyles.Add(new RowStyle(SizeType.Absolute, 35)); grid.RowStyles.Add(new RowStyle(SizeType.Absolute, 45)); f.Controls.Add(grid);
                var trigger = new TextBox { Text = item == null ? "" : item.Trigger, Dock = DockStyle.Fill };
                var label = new TextBox { Text = item == null ? "" : item.Label, Dock = DockStyle.Fill };
                var category = new TextBox { Text = "Work", Dock = DockStyle.Fill, Enabled = item == null };
                var body = new TextBox { Text = item == null ? "" : item.Text.Replace("\r\n", "\n").Replace("\n", "\r\n"), Multiline = true, AcceptsReturn = true, AcceptsTab = true, ScrollBars = ScrollBars.Both, Dock = DockStyle.Fill };
                var enabled = new CheckBox { Text = "Enabled", Checked = item == null || item.Enabled, AutoSize = true };
                string[] names = { "Trigger", "Label", "Category", "Replacement" }; Control[] inputs = { trigger, label, category, body };
                for (int i = 0; i < 4; i++) { grid.Controls.Add(new Label { Text = names[i], AutoSize = true }, 0, i); grid.Controls.Add(inputs[i], 1, i); }
                grid.Controls.Add(enabled, 1, 4);
                var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft };
                var cancel = new Button { Text = "Cancel", DialogResult = DialogResult.Cancel, AutoSize = true };
                var save = new Button { Text = "Save", AutoSize = true }; buttons.Controls.Add(cancel); buttons.Controls.Add(save); grid.Controls.Add(buttons, 1, 5); f.CancelButton = cancel;
                bool saved = false;
                save.Click += delegate
                {
                    try
                    {
                        string t = trigger.Text;
                        if (string.IsNullOrWhiteSpace(t) || t.Contains("\r") || t.Contains("\n")) throw new ArgumentException("Enter a non-empty, single-line trigger.");
                        bool duplicate = false;
                        foreach (var other in store.Items) if (other != item && string.Equals(other.Trigger, t, StringComparison.Ordinal)) duplicate = true;
                        var active = new Library(store.Root); active.Load();
                        foreach (var m in active.Matches) foreach (string existing in m.Triggers)
                            if (existing == t && (item == null || item.Trigger != t)) duplicate = true;
                        if (duplicate && MessageBox.Show(f, "This trigger already exists. Keep both snippets?", "Duplicate trigger", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
                        // Preserve the original newline convention when unchanged; normalize only edited Windows text.
                        string value = body.Text.Replace("\r\n", "\n");
                        if (item != null && value == item.Text.Replace("\r\n", "\n")) value = item.Text;
                        store.Save(item, t, value, label.Text, enabled.Checked, category.Text.Trim(), false);
                        saved = true; f.DialogResult = DialogResult.OK; f.Close();
                    }
                    catch (Exception ex) { MessageBox.Show(f, ex.Message, "Couldn't save", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
                };
                f.FormClosing += delegate(object sender, FormClosingEventArgs e)
                {
                    bool changed = trigger.Text != (item == null ? "" : item.Trigger) || label.Text != (item == null ? "" : item.Label) || body.Text.Replace("\r\n", "\n") != (item == null ? "" : item.Text.Replace("\r\n", "\n")) || enabled.Checked != (item == null || item.Enabled);
                    if (!saved && changed && MessageBox.Show(f, "Discard unsaved changes?", "Close editor", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) e.Cancel = true;
                };
                f.ShowDialog(this); Filter();
            }
        }
    }
}

'@

try {
    Add-Type -AssemblyName System.Windows.Forms, System.Drawing
    if (-not ('PortableExpander.App' -as [type])) {
        Add-Type -TypeDefinition $source -ReferencedAssemblies System.Windows.Forms, System.Drawing, System.Core -Language CSharp -IgnoreWarnings
    }
    [PortableExpander.App]::Start($folder, $scriptPath)
}
catch {
    $msg = "Portable Text Expander couldn't start.`r`n`r`n" + $_.Exception.Message
    try { Add-Content -Path (Join-Path $folder 'expander.log') -Value ((Get-Date).ToString('s') + '  ' + ($_ | Out-String)) } catch {}
    [System.Windows.Forms.MessageBox]::Show($msg, 'Portable Text Expander') | Out-Null
}
