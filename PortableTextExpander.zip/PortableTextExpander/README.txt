NOTEPAD COMPATIBILITY UPDATE
Windows Notepad is now detected by its executable name. In auto mode, text
is pasted through the clipboard, with at least 750 ms before restoration.
Word and Notepad++ retain their normal behaviour. No notepad.yml is needed.

UPGRADING YOUR EXISTING FOLDER
Exit the running expander. Replace only TextExpander.ps1 with the file from
this ZIP, preserving your own snippets and settings. If you added the earlier
config/notepad.yml, remove it. If you changed config/default.yml to force
clipboard globally, set backend: auto (or comment out the backend line) to
restore automatic selection. Launch Start Text Expander.bat again.
No new installation, administrator rights or external dependency is needed.

Validation: the only engine change is the targeted settings selection above.
Package structure and unchanged files were checked. Windows execution still
needs confirmation on your PC. Test sal.., c1.., c2.. and udf.. in Notepad.

PORTABLE TEXT EXPANDER - SNIPPET MANAGER EDITION
================================================
Windows PowerShell / Windows Forms. No installation or admin account required.

FIRST RUN / UPGRADE
1. Exit your currently running expander using its tray menu.
2. Extract this ZIP into a NEW folder. Do not run it inside the ZIP.
3. Double-click Start Text Expander.bat as before.
4. Right-click the TE tray icon > Manage snippets, or double-click the icon.
5. Try a new snippet in Notepad, then test your usual applications.

The supplied match and config files are unchanged from your uploaded ZIP.
If your working copy has newer snippets, exit the app and copy your current
match and config folders into this new folder before launching.
The original working ZIP is included in original/ for rollback.

SNIPPET MANAGER
- Search by trigger, replacement, label or filename/category.
- New: trigger, optional label, category, multiline replacement and Enabled.
- Save applies changes; Cancel prompts before discarding changed text.
- Edit, Delete and Enable / Disable operate on the selected basic snippet.
- Duplicate triggers warn before saving; keeping both is allowed.
- New snippets live in match/managed/<category>/ as individual YAML files.
  Existing snippets remain in their original files. To reorganize existing
  files, close the manager and move them within match using File Explorer.
- Refresh rereads external changes. A stale editor refuses to overwrite them.
- Expansions pause while the manager is open and return to the previous
  paused/running state when it closes.

ADVANCED YAML
Snippets with variables, forms, regexes, extra options, anchors, comments
inside the entry, or an unsupported layout are shown as Advanced. They stay
read-only in the basic editor. Select one and use Open YAML for manual edits,
then click Refresh. Existing advanced fields and other entries are preserved.
The manager lists YAML files under match, including underscore-prefixed files;
those files only participate in expansion if imported by an active file.
Imports outside match continue to work in the engine, but aren't managed here.

Enabled/Disabled is saved as portable_enabled: true/false. This is a Portable
Text Expander feature; do not rely on espanso honoring that flag if you copy
a disabled snippet back to espanso.

BACKUP / RESTORE
Every manager save, deletion or enable/disable change first copies the entire
match folder into backups/snippets-<timestamp>-<id>/match.
Backup makes the same snapshot on demand.
Restore: select a snippets-... folder inside this application's backups folder.
Restore replaces the entire match folder, after backing up the current one.
Backups include files beneath match; they do not include config, external
imports, images or scripts stored elsewhere. Manual YAML edits are not
automatically backed up: click Backup first. Backups are kept until you remove
them yourself. Keep this entire app folder in a writable location.

ROLLBACK
Exit the new app and run your original folder again, or extract the ZIP in
original/ into another folder and launch it. The original engine does not
honor portable_enabled; use the original snippets or restore a pre-edit backup.

VERIFICATION STATUS
Checked here: all 55 original snippet boundaries against an independent YAML
parser; unchanged launcher, config and snippet bytes; unchanged expansion and
rendering code; source integration and balanced C# delimiters.
Windows Forms execution, C# compilation under Windows PowerShell, keyboard
hooks, and interactive save/restore still require Windows testing.
Optional developer check on Windows:
  powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File .\Test-SnippetManager.ps1
It compiles the embedded source and exercises storage operations on temporary
copies of the supplied base.yml. It does not start keyboard hooks or modify
your live snippets. Use the unmodified supplied base.yml for that check.

The original documentation is included as README-original.txt.
