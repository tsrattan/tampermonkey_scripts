PORTABLE TEXT EXPANDER  (espanso-compatible)
============================================
A text expander for Windows that reads espanso snippet files. No install
and no admin rights: it runs on the PowerShell built into Windows, so you
can carry the folder on a USB stick or keep it in OneDrive.

GETTING STARTED
1. Unzip this folder anywhere.
2. Double-click "Start Text Expander.bat".
3. A blue "TE" icon appears near the clock (check the ^ overflow arrow).
4. Type  date..  or  eos..  in any app.

YOUR SNIPPETS
Snippets live in the "match" folder, written exactly like espanso:
  match\base.yml     <- your snippets (already filled in)
  config\default.yml <- optional settings (same names as espanso)
Every .yml file in "match" (and its sub-folders) is loaded. Files that
start with _ are only loaded when another file imports them, the same
as espanso. Save a file and the changes apply in about 2 seconds.

BRINGING OVER YOUR ESPANSO FILES
Option A: Right-click the TE icon > "Import my espanso snippets...".
          It finds espanso on this PC (or lets you pick the folder),
          backs up your current snippets, then copies over match, config,
          images and scripts.
Option B: Copy your espanso .yml files into the "match" folder yourself.

WHAT WORKS (same YAML as espanso)
- trigger, triggers: [a, b], regex (named groups become variables)
- replace (including | and > multi-line blocks, "\n", "\u20ac")
- word, left_word, right_word, propagate_case, uppercase_style
- $|$ cursor position
- vars and global_vars: date (strftime format, offset, locale), clipboard,
  echo, random, choice, shell (PowerShell by default, or cmd / wsl / pwsh),
  script (%CONFIG% works), match (nested snippets), form
- form: with [[fields]] and form_fields (text, multiline, choice, list)
- markdown and html (pasted as formatted text), image_path ($CONFIG works)
- label, search_terms, force_mode, force_clipboard, imports
- Two snippets with the same trigger: you get a list to pick from
- ALT+SPACE opens a search box for all your snippets
- Press Backspace straight after an expansion to undo it
- App-specific config files (filter_exec / filter_title / filter_class)
  with enable, backend and clipboard_threshold

NOT SUPPORTED: espanso packages from the online hub (copy their .yml files
in manually instead), toggle_key, and Ctrl-key triggers like "\x05".

TRAY ICON MENU (right-click)
  Pause expansions / Search snippets / Edit snippets / Show snippet list
  (also lists any file problems) / Reload / Open folder /
  Import my espanso snippets / Start with Windows / Exit

GOOD TO KNOW
- When one trigger ends with another (eos.. and os..), the longer one
  wins, so eos.. gives "1830 End of Shift." as you'd expect.
- If a YAML file has a mistake, the other files still load. The tray
  icon tells you the file and line number.
- Expansion doesn't work inside apps running "as administrator" unless
  you also start the expander as administrator. Windows blocks this.
- A console window may flash for a moment when it starts. That's normal.
- On some company-managed PCs, IT policy blocks PowerShell scripts. If it
  can't start you'll see a message, and the details go to expander.log.
