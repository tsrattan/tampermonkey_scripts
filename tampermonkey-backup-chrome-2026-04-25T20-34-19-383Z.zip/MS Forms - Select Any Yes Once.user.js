// ==UserScript==
// @name         MS Forms - Select Any Yes Once
// @match        https://forms.office.com/Pages/ResponsePage.aspx*
// @match        https://forms.office.com/*
// @run-at       document-idle
// @all-frames   true
// @grant        none
// ==/UserScript==

(function () {
  'use strict';

  function click(el) {
    if (!el) return;
    el.click();
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function findQuestion(el) {
    return (
      el.closest('[data-automation-id*="question"]') ||
      el.closest('[role="group"]') ||
      el.closest('fieldset') ||
      el.closest('div')
    );
  }

  function selectAnyYesOnce() {
    const yesItems = [...document.querySelectorAll('[role="radio"], label, span, div')]
      .filter(el => (el.innerText || el.getAttribute("aria-label") || "").trim().toLowerCase() === "yes");

    yesItems.forEach(yesEl => {
      const question = findQuestion(yesEl);
      if (!question) return;

      const alreadyAnswered = question.querySelector(
        '[role="radio"][aria-checked="true"], input[type="radio"]:checked'
      );

      if (alreadyAnswered) return;

      const clickable =
        yesEl.closest('[role="radio"]') ||
        yesEl.closest('label') ||
        yesEl.parentElement;

      click(clickable);
    });
  }

  setTimeout(selectAnyYesOnce, 1000);
  setTimeout(selectAnyYesOnce, 2500);
  setTimeout(selectAnyYesOnce, 5000);
})();