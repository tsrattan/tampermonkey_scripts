chrome.commands.onCommand.addListener((command) => {
  if (command !== "run-autofill") return;
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    const tab = tabs?.[0];
    if (!tab?.id || /^chrome:|^edge:|^about:/i.test(tab.url || "")) return;
    chrome.storage.local.get(["profiles", "activeProfile"], data => {
      const profiles = data.profiles || { Default: { rules: [] } };
      const activeProfile = data.activeProfile || Object.keys(profiles)[0];
      const profile = profiles[activeProfile] || { rules: [], identity: {} };
      const identityRules = Object.entries(profile.identity || {})
        .filter(([_, value]) => String(value || "").trim())
        .map(([fieldKey, value]) => ({
          id: `identity-${fieldKey}`, type: "smart", fieldKey, pattern: fieldKey, value,
          enabled: true, delay: 40, matchedAttr: "identity-semantic", meta: { highlight: true, source: "identity" }
        }));
      const rules = [...identityRules, ...(profile.rules || [])]
        .filter(rule => rule.enabled !== false)
        .filter(rule => !rule.urlPattern || String(tab.url || "").includes(rule.urlPattern));
      if (!rules.length) return;
      chrome.scripting.executeScript({ target: { tabId: tab.id }, args: [rules], func: runAutofill });
    });
  });
});

function runAutofill(rules) {
  const FIELD_DEFS = {
    fullName:[/^(.cc-)?name$/i,/full.?name/i,/your.?name/i,/^name$/i], firstName:[/given.?name/i,/first.?name/i,/fname/i,/forename/i], lastName:[/family.?name/i,/last.?name/i,/surname/i,/lname/i], email:[/^email$/i,/e-?mail/i,/email.?address/i], phone:[/^tel$/i,/phone/i,/mobile/i,/telephone/i], address1:[/address.?line.?1/i,/street.?address/i,/address1/i], address2:[/address.?line.?2/i,/address2/i], city:[/city/i,/suburb/i,/town/i], state:[/state/i,/province/i,/region/i], postcode:[/postal.?code/i,/post.?code/i,/zip/i], country:[/country/i], company:[/organization/i,/organisation/i,/company/i], jobTitle:[/job.?title/i,/position/i,/role/i], username:[/user.?name/i,/login/i]
  };
  const clean=s=>String(s||"").replace(/\s+/g," ").trim(); const low=s=>clean(s).toLowerCase(); const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  function expandValue(value){ const d=new Date(); const pad=n=>String(n).padStart(2,"0"); const rand=n=>Math.floor(Math.random()*n); return String(value ?? "").replace(/{{\s*date:today\s*}}/gi, `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`).replace(/{{\s*today\s*}}/gi, `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`).replace(/{{\s*randomEmail\s*}}/gi, `test${Date.now()}${rand(999)}@example.com`).replace(/{{\s*randomPhone\s*}}/gi, `04${String(10000000+rand(89999999)).slice(0,8)}`).replace(/{{\s*uuid\s*}}/gi, crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${rand(999999)}`); }
  function mark(el, ok=true){ if(!el) return; const old=el.style.boxShadow; el.style.boxShadow = ok ? "0 0 0 3px rgba(16,185,129,.55)" : "0 0 0 3px rgba(239,68,68,.55)"; setTimeout(()=>{ el.style.boxShadow=old; }, 1600); } const isMs=/forms\.cloud\.microsoft|forms\.office\.com|forms\.microsoft\.com/i.test(location.hostname);
  const visible=el=>{ if(!el||el.disabled) return false; const st=getComputedStyle(el), r=el.getBoundingClientRect(); return st.display!=="none"&&st.visibility!=="hidden"&&r.width>0&&r.height>0; };
  const cssEsc=window.CSS?.escape || (v=>String(v).replace(/[^a-zA-Z0-9_-]/g,"\\$&"));
  const groups=()=>[...document.querySelectorAll("[data-automation-id*='question'], [data-automation-id*='Question'], [role='radiogroup'], [role='group'], .office-form-question, .question, li, section")].filter(visible);
  const groupForIndex=i=>Number.isInteger(i)&&i>=0?groups()[i]:null;
  const groupOf=el=>groups().find(g=>g.contains(el));
  const textOf=el=>clean(["aria-label","aria-labelledby","aria-describedby","autocomplete","id","name","placeholder","title","data-testid","data-automation-id","value"].map(a=>el.getAttribute?.(a)).filter(Boolean).join(" ")+" "+(el.labels?[...el.labels].map(l=>l.textContent).join(" "):"")+" "+(groupOf(el)?.innerText||"")+" "+(el.textContent||""));
  const typeOf=p=>{ p=clean(p); if(!p)return"partial"; if(p.startsWith("//")||p.startsWith("/html/"))return"xpath"; if(p.startsWith("/")&&p.lastIndexOf("/")>0)return"regex"; if(p.startsWith('"')&&p.endsWith('"'))return"exact"; if(/^[.#\[]|^(input|select|textarea|button|div|span|label|form)\b/i.test(p))return"css"; return"partial"; };
  const match=(val,pat,t)=>{ val=clean(val); pat=clean(pat); if(!val||!pat)return false; if(t==="exact")return val===pat.replace(/^"|"$/g,""); if(t==="regex"){const m=pat.match(/^\/(.*)\/([gimsuy]*)$/); try{return m?new RegExp(m[1],m[2]).test(val):false}catch{return false}} return low(val).includes(low(pat.replace(/^"|"$/g,""))); };
  const inputs=()=>[...document.querySelectorAll("input:not([type]), input[type='text'], input[type='email'], input[type='tel'], input[type='number'], input[type='search'], input[type='url'], textarea, [contenteditable='true'], [role='textbox']")].filter(visible);
  const dates=()=>[...document.querySelectorAll("input[type='date'], input[type='datetime-local'], input[type='month'], input[type='time']")].filter(visible);
  const drops=()=>[...document.querySelectorAll("select, [role='combobox'], [aria-haspopup='listbox'], [aria-expanded][role='button'], button[aria-haspopup], div[aria-haspopup]")].filter(visible);
  const checks=()=>[...document.querySelectorAll("input[type='checkbox'], [role='checkbox']")].filter(visible);
  const radios=()=>[...document.querySelectorAll("input[type='radio'], [role='radio']")].filter(visible);
  function cands(rule, scope=document){ if(rule.type==="dropdown") return drops().filter(e=>scope===document||scope.contains(e)); if(rule.type==="checkbox") return checks().filter(e=>scope===document||scope.contains(e)); if(rule.type==="radio") return radios().filter(e=>scope===document||scope.contains(e)); if(rule.type==="date") return dates().filter(e=>scope===document||scope.contains(e)); return inputs().filter(e=>scope===document||scope.contains(e)); }
  function find(rule){
    const p=rule.pattern||rule.selector||rule.fieldKey, t=rule.patternType||typeOf(p);
    if (rule.groupIndex!==null && rule.groupIndex!==undefined) { const g=groupForIndex(Number(rule.groupIndex)); if(g){ const arr=cands(rule,g); if(rule.type==="input" && rule.matchedAttr==="ms-react-other"){ const ans=arr.find(e=>low(e.placeholder).includes("answer")||low(textOf(e)).includes("answer")); if(ans) return ans; } if(arr.length) return arr[Math.min(Number(rule.controlIndex)||0, arr.length-1)]; } }
    if (rule.type==="smart" && rule.fieldKey) return bestSemantic(rule.fieldKey, rule.value);
    if (t==="css") { try{const e=document.querySelector(p); if(e&&visible(e))return e;}catch{} }
    if (t==="xpath") { try{const e=document.evaluate(p,document,null,XPathResult.FIRST_ORDERED_NODE_TYPE,null).singleNodeValue; if(e&&visible(e))return e;}catch{} }
    let best=null,score=-1; for(const e of cands(rule)){ let s=0; if(match(textOf(e),p,t)) s+=70; if(e.id && document.querySelector(`label[for="${cssEsc(e.id)}"]`) && match(document.querySelector(`label[for="${cssEsc(e.id)}"]`).textContent,p,t)) s+=25; if(s>score){score=s;best=e;} } return score>0?best:null;
  }
  function bestSemantic(key){ const defs=FIELD_DEFS[key]||[]; let best=null,score=-1; for(const e of inputs().concat(dates())){ const attrs={autocomplete:e.getAttribute("autocomplete")||"",name:e.name||"",id:e.id||"",placeholder:e.placeholder||"",aria:e.getAttribute("aria-label")||"",label:e.labels?[...e.labels].map(l=>l.textContent).join(" "):"", group: groupOf(e)?.innerText||""}; let s=0; for(const re of defs){ if(re.test(attrs.autocomplete))s=Math.max(s,100); if(re.test(attrs.name))s=Math.max(s,90); if(re.test(attrs.id))s=Math.max(s,85); if(re.test(attrs.aria))s=Math.max(s,80); if(re.test(attrs.placeholder))s=Math.max(s,70); if(re.test(attrs.label))s=Math.max(s,65); if(re.test(attrs.group))s=Math.max(s,45); } if(s>score){score=s;best=e;} } return score>=45?best:null; }
  function setVal(el,value){ value=expandValue(value); mark(el,true); el.focus(); if(el.isContentEditable||el.getAttribute("role")==="textbox"){ el.textContent=value; } else { const proto=el instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype; const setter=Object.getOwnPropertyDescriptor(proto,"value")?.set; setter?setter.call(el,value):(el.value=value); } el.dispatchEvent(new InputEvent("input",{bubbles:true,inputType:"insertText",data:value})); el.dispatchEvent(new Event("change",{bubbles:true})); }
  function setSelect(sel,w){ const opt=[...sel.options].find(o=>low(o.textContent)===low(w)||low(o.textContent).includes(low(w))||o.value===w); if(!opt)return false; mark(sel,true); sel.value=opt.value; sel.dispatchEvent(new Event("input",{bubbles:true})); sel.dispatchEvent(new Event("change",{bubbles:true})); return true; }
  async function option(w, timeout=1100){ const start=Date.now(); while(Date.now()-start<timeout){ const opts=[...document.querySelectorAll("[role='option'], [role='menuitemradio'], li[role='option']")].filter(visible); const hit=opts.find(o=>low(o.getAttribute("aria-label")||o.textContent).includes(low(w))); if(hit)return hit; await sleep(60); } return null; }
  function toast(msg,type="success"){ const t=document.createElement("div"); t.textContent=msg; t.style.cssText=`position:fixed;top:18px;right:18px;z-index:2147483647;padding:12px 16px;border-radius:14px;font:700 13px system-ui;background:${type==="error"?"#ef4444":"#10b981"};color:#fff;box-shadow:0 14px 30px rgba(0,0,0,.24)`; document.documentElement.appendChild(t); setTimeout(()=>t.remove(),2200); }
  async function waitGroupInput(gi, beforeCount){ if(!Number.isInteger(gi)||gi<0)return; const start=Date.now(); while(Date.now()-start<900){ const g=groupForIndex(gi); if(g && cands({type:"input"},g).length>beforeCount) return; await sleep(50); } }
  async function run(){ let changed=0; const priority={dropdown:1,radio:2,checkbox:3,smart:4,input:5,date:6,click:7,submit:8,wait:9}; const sorted=[...rules].filter(r=>r.enabled!==false).sort((a,b)=>(priority[a.type]||50)-(priority[b.type]||50)); for(const rule of sorted){ if(rule.type==="wait"){await sleep(Number(rule.value)||300); continue;} const el=find(rule); if(!el) continue; if(["input","date","smart"].includes(rule.type)){ setVal(el,rule.value); changed++; } else if(rule.type==="checkbox"){ const want=rule.value===true||rule.value==="true"; const checked=el instanceof HTMLInputElement?el.checked:el.getAttribute("aria-checked")==="true"; if(checked!==want) el.click(); changed++; } else if(rule.type==="radio"){ el.click(); changed++; } else if(rule.type==="dropdown"){ const gi=Number.isInteger(rule.groupIndex)?rule.groupIndex:null; const before=gi!==null && groupForIndex(gi)?cands({type:"input"},groupForIndex(gi)).length:0; if(el instanceof HTMLSelectElement){ if(setSelect(el,rule.value)) changed++; } else { el.click(); const opt=await option(rule.value); if(opt){ opt.click(); changed++; await waitGroupInput(gi,before); } } } else if(rule.type==="click"||rule.type==="submit"){ el.click(); changed++; } await sleep(Math.min(Number(rule.delay)||60,700)); } toast(changed?`✓ Autofilled ${changed} field${changed===1?"":"s"}`:"No matching fields found",changed?"success":"error"); }
  run();
}
