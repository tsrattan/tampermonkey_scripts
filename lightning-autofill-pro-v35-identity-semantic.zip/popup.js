let profiles = {};
let activeProfile = "Default";
const EMPTY_IDENTITY = { fullName:"", firstName:"", lastName:"", email:"", phone:"", address1:"", address2:"", city:"", state:"", postcode:"", country:"", company:"", jobTitle:"", username:"" };
const DEFAULT_PROFILE = { Default: { rules: [], identity: { ...EMPTY_IDENTITY } } };
const TYPE_ICONS = { smart: "⚡", input: "📝", dropdown: "📋", checkbox: "☑️", radio: "🔘", date: "📅", click: "👆", wait: "⏱️", submit: "🚀" };
const $ = (id) => document.getElementById(id);

function detectPatternType(pattern) {
  const p = String(pattern || "").trim();
  if (!p) return "partial";
  if (p.startsWith("//") || p.startsWith("/html/")) return "xpath";
  if (p.startsWith("/") && p.lastIndexOf("/") > 0) return "regex";
  if (p.startsWith('"') && p.endsWith('"')) return "exact";
  if (/^[.#\[]|^(input|select|textarea|button|div|span|label|form)\b/i.test(p)) return "css";
  return "partial";
}
function normaliseRule(rule = {}) {
  const pattern = rule.pattern || rule.selector || rule.fieldKey || "";
  return {
    id: rule.id || crypto.randomUUID?.() || String(Date.now() + Math.random()),
    type: rule.type || (rule.fieldKey ? "smart" : "input"),
    fieldKey: rule.fieldKey || "",
    pattern,
    selector: rule.selector || (detectPatternType(pattern) === "css" ? pattern : ""),
    patternType: rule.patternType || detectPatternType(pattern),
    matchedAttr: rule.matchedAttr || (rule.fieldKey ? "semantic" : rule.selector ? "css" : "manual"),
    value: rule.value ?? "",
    order: Number.isFinite(Number(rule.order)) ? Number(rule.order) : 0,
    groupIndex: Number.isFinite(Number(rule.groupIndex)) ? Number(rule.groupIndex) : null,
    controlIndex: Number.isFinite(Number(rule.controlIndex)) ? Number(rule.controlIndex) : null,
    delay: Number.isFinite(Number(rule.delay)) ? Number(rule.delay) : 80,
    enabled: rule.enabled !== false,
    urlPattern: rule.urlPattern || "",
    meta: rule.meta || {}
  };
}
function normaliseIdentity(identity = {}) {
  const out = { ...EMPTY_IDENTITY };
  Object.keys(out).forEach(key => { out[key] = String(identity?.[key] ?? "").trim(); });
  if (!out.fullName && (out.firstName || out.lastName)) out.fullName = `${out.firstName} ${out.lastName}`.trim();
  return out;
}
function normaliseProfiles(input) {
  const src = input && typeof input === "object" ? input : DEFAULT_PROFILE;
  const out = {};
  Object.entries(src).forEach(([name, profile]) => {
    const cleanName = String(name || "Default").trim() || "Default";
    out[cleanName] = {
      rules: Array.isArray(profile?.rules) ? profile.rules.map(normaliseRule) : [],
      identity: normaliseIdentity(profile?.identity || profile?.profile || {})
    };
  });
  return Object.keys(out).length ? out : structuredClone(DEFAULT_PROFILE);
}
function identityRulesForProfile(profile) {
  const identity = normaliseIdentity(profile?.identity || {});
  return Object.entries(identity)
    .filter(([_, value]) => String(value || "").trim())
    .map(([fieldKey, value]) => normaliseRule({ type: "smart", fieldKey, pattern: fieldKey, value, delay: 40, enabled: true, matchedAttr: "identity-semantic", meta: { highlight: true, source: "identity" } }));
}
function activeProfileObject() {
  if (!profiles[activeProfile]) profiles[activeProfile] = { rules: [], identity: { ...EMPTY_IDENTITY } };
  profiles[activeProfile].identity = normaliseIdentity(profiles[activeProfile].identity || {});
  return profiles[activeProfile];
}
function escapeHtml(value) { return String(value ?? "").replace(/[&<>"]/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[ch])); }
function save(cb) { chrome.storage.local.set({ profiles, activeProfile }, () => cb?.()); }
function load(cb) { chrome.storage.local.get(["profiles", "activeProfile"], data => { profiles = normaliseProfiles(data.profiles); activeProfile = profiles[data.activeProfile] ? data.activeProfile : Object.keys(profiles)[0]; save(cb); }); }
function currentRules() { return activeProfileObject().rules; }
function updateStats() { $("profileCount").textContent = Object.keys(profiles).length; const identityCount = Object.values(activeProfileObject().identity || {}).filter(Boolean).length; $("ruleCount").textContent = currentRules().filter(r => r.enabled !== false).length + identityCount; }
function renderProfiles() { const sel = $("profileSelect"); sel.innerHTML = ""; Object.keys(profiles).sort((a,b)=>a.localeCompare(b)).forEach(name => { const opt = document.createElement("option"); opt.value = name; opt.textContent = name; opt.selected = name === activeProfile; sel.appendChild(opt); }); updateStats(); }
function renderRules() {
  const list = $("rulesList"); const rules = currentRules(); updateStats();
  if (!rules.length) { list.innerHTML = `<div class="empty-state"><div class="big">✨</div><strong>No rules saved yet</strong><span>Fill a page and click Capture Page, or add your first manual/smart rule.</span></div>`; return; }
  list.innerHTML = "";
  rules.forEach((rule, index) => {
    const card = document.createElement("div"); card.className = "rule-card" + (rule.enabled === false ? " disabled" : "");
    const label = rule.type === "smart" ? `${rule.fieldKey}: ${rule.value}` : rule.type === "checkbox" ? (rule.value === true || rule.value === "true" ? "Check" : "Uncheck") : rule.value;
    const meta = [rule.matchedAttr || rule.patternType, rule.pattern || rule.selector, rule.groupIndex !== null ? `Q${rule.groupIndex+1}` : "", rule.urlPattern].filter(Boolean).join(" · ");
    card.innerHTML = `<div class="rule-icon">${TYPE_ICONS[rule.type] || "•"}</div><div class="rule-main"><div class="rule-title">${escapeHtml(label || "(blank value)")}</div><div class="rule-meta">${escapeHtml(meta)}</div></div><div class="rule-actions"><button class="mini-btn toggle">${rule.enabled === false ? "On" : "Off"}</button><button class="mini-btn remove">×</button></div>`;
    card.querySelector(".toggle").onclick = () => { profiles[activeProfile].rules[index].enabled = rule.enabled === false; save(renderRules); };
    card.querySelector(".remove").onclick = () => { profiles[activeProfile].rules.splice(index, 1); save(renderRules); };
    list.appendChild(card);
  });
}
function setActiveTab(name) { document.querySelectorAll(".tab").forEach(t => t.classList.toggle("active", t.dataset.tab === name)); document.querySelectorAll(".section").forEach(s => s.classList.remove("active")); $(`tab-${name}`).classList.add("active"); }
document.querySelectorAll(".tab").forEach(tab => tab.onclick = () => setActiveTab(tab.dataset.tab));
function renderIdentity() {
  const identity = activeProfileObject().identity || {};
  document.querySelectorAll("[data-idkey]").forEach(input => { input.value = identity[input.dataset.idkey] || ""; });
}
function readIdentityFromForm() {
  const identity = {};
  document.querySelectorAll("[data-idkey]").forEach(input => { identity[input.dataset.idkey] = input.value.trim(); });
  return normaliseIdentity(identity);
}
function saveIdentityFromForm(showAlert = true) {
  activeProfileObject().identity = readIdentityFromForm();
  save(() => { updateStats(); if (showAlert) alert("✓ Identity profile saved."); });
}
function addIdentityRulesToRules() {
  saveIdentityFromForm(false);
  const smartRules = identityRulesForProfile(activeProfileObject());
  const existingKeys = new Set(currentRules().filter(r => r.type === "smart").map(r => r.fieldKey));
  smartRules.forEach(rule => { if (!existingKeys.has(rule.fieldKey)) currentRules().push(rule); });
  save(() => { renderRules(); setActiveTab("rules"); alert(`✓ Added ${smartRules.length} smart identity rules.`); });
}

$("profileSelect").onchange = e => { activeProfile = e.target.value; save(() => { renderRules(); renderProfiles(); renderIdentity(); }); };
$("addProfileBtn").onclick = () => { const name = prompt("Profile name:")?.trim(); if (!name) return; if (profiles[name]) return alert("Profile already exists."); profiles[name] = { rules: [] }; activeProfile = name; save(() => { renderProfiles(); renderRules(); }); };
$("delProfileBtn").onclick = () => { if (Object.keys(profiles).length <= 1) return alert("You can't delete the last profile."); if (!confirm(`Delete profile "${activeProfile}"?`)) return; delete profiles[activeProfile]; activeProfile = Object.keys(profiles)[0]; save(() => { renderProfiles(); renderRules(); }); };
const saveIdentityBtnEl = $("saveIdentityBtn");
if (saveIdentityBtnEl) saveIdentityBtnEl.onclick = () => saveIdentityFromForm(true);
const addIdentityRulesBtnEl = $("addIdentityRulesBtn");
if (addIdentityRulesBtnEl) addIdentityRulesBtnEl.onclick = addIdentityRulesToRules;
$("addRuleBtn").onclick = () => {
  const pattern = $("newPattern").value.trim(); const value = $("newValue").value.trim(); const type = $("newType").value; const order = Math.max(0, parseInt($("newOrder").value,10)||0); const delay = Math.max(0, parseInt($("newDelay").value,10)||80); const urlPattern = $("newUrl").value.trim();
  if (!pattern) return alert("Selector, matching text, or smart key is required."); if (!["checkbox","radio","click","submit","wait"].includes(type) && !value) return alert("Value is required for this rule type.");
  const smartKeys = ["fullName","firstName","lastName","email","phone","address1","address2","city","state","postcode","country","company","jobTitle","username"];
  currentRules().push(normaliseRule({ type: smartKeys.includes(pattern) ? "smart" : type, fieldKey: smartKeys.includes(pattern) ? pattern : "", pattern, patternType: detectPatternType(pattern), matchedAttr: smartKeys.includes(pattern) ? "semantic" : detectPatternType(pattern), value, order, delay, enabled: true, urlPattern }));
  save(() => { ["newPattern","newValue","newUrl"].forEach(id => $(id).value = ""); $("newOrder").value = "0"; renderRules(); setActiveTab("rules"); });
};
function getActiveTab(callback) { chrome.tabs.query({ active: true, currentWindow: true }, tabs => { const tab = tabs?.[0]; if (!tab?.id) return alert("No active tab found."); if (/^chrome:|^edge:|^about:/i.test(tab.url || "")) return alert("Chrome blocks extensions on this page. Try a normal website tab."); callback(tab); }); }
function rulesForUrl(url) { const autoRules = identityRulesForProfile(activeProfileObject()); const rules = [...autoRules, ...currentRules()]; return rules.filter(r => r.enabled !== false).filter(r => !r.urlPattern || String(url||"").includes(r.urlPattern)); }
$("runBtn").onclick = () => getActiveTab(tab => { const matched = rulesForUrl(tab.url); if (!matched.length) return alert("No enabled matching rules for this page."); chrome.scripting.executeScript({ target: { tabId: tab.id }, args: [matched], func: runAutofill }); });
$("captureBtn").onclick = () => getActiveTab(tab => { chrome.scripting.executeScript({ target: { tabId: tab.id }, func: captureFilledFields }, results => { if (chrome.runtime.lastError) return alert(chrome.runtime.lastError.message); const captured = (results?.[0]?.result || []).map(normaliseRule); if (!captured.length) return alert("Nothing captured — fill the form first, then capture."); currentRules().push(...captured); save(() => { renderRules(); setActiveTab("rules"); alert(`✓ Captured ${captured.length} rules into "${activeProfile}".`); }); }); });
$("exportBtn").onclick = () => { const blob = new Blob([JSON.stringify({ profiles, activeProfile, exportedAt: new Date().toISOString() }, null, 2)], { type: "application/json" }); const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `lightning-autofill-${activeProfile.replace(/[^a-z0-9_-]/gi,"_")}.json`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href),1000); };
function openImportPage() {
  const url = chrome.runtime.getURL("import.html");
  chrome.tabs.create({ url });
}

const openImportPageBtnEl = $("openImportPageBtn");
if (openImportPageBtnEl) {
  openImportPageBtnEl.addEventListener("click", openImportPage);
}

function captureFilledFields() {
  const clean = s => String(s || "").replace(/\s+/g," ").trim();
  const isVisible = el => { if (!el || el.disabled) return false; const st=getComputedStyle(el), r=el.getBoundingClientRect(); return st.display!=="none" && st.visibility!=="hidden" && r.width>0 && r.height>0; };
  const isMs = /forms\.cloud\.microsoft|forms\.office\.com|forms\.microsoft\.com/i.test(location.hostname);
  const groups = [...document.querySelectorAll("[data-automation-id*='question'], [data-automation-id*='Question'], [role='radiogroup'], [role='group'], .office-form-question, .question, li, section")].filter(isVisible);
  const groupOf = el => groups.findIndex(g => g.contains(el));
  const qText = el => { const gi=groupOf(el); const g=groups[gi]; const t=clean(g?.querySelector("[data-automation-id*='questionTitle'], [role='heading'], legend, h1,h2,h3,h4,label")?.textContent || g?.innerText || el.getAttribute("aria-label") || el.placeholder || el.name || ""); return t.replace(/^\d+\.\s*/,"").slice(0,160); };
  const cssEsc = window.CSS?.escape || (v=>String(v).replace(/[^a-zA-Z0-9_-]/g,"\\$&"));
  const selectorFor = el => el.id && !/^\d+$/.test(el.id) ? `#${cssEsc(el.id)}` : el.name ? `${el.tagName.toLowerCase()}[name="${String(el.name).replace(/"/g,'\\"')}"]` : "";
  const out=[]; const seen=new Set();
  function add(el,type,value,opt={}) { if (!isVisible(el) && !["radio","checkbox"].includes(type)) return; const gi=groupOf(el); const pattern = isMs && gi>=0 ? qText(el) : selectorFor(el) || qText(el) || el.getAttribute("aria-label") || el.placeholder || el.name; if (!pattern) return; const key = `${type}|${gi}|${pattern}|${value}|${opt.optionText||""}`; if (seen.has(key)) return; seen.add(key); out.push({ type, pattern, selector: selectorFor(el), patternType: isMs && gi>=0 ? "partial" : (selectorFor(el)?"css":"partial"), matchedAttr: opt.matchedAttr || (isMs?"ms-react-question":"capture"), value, order:0, groupIndex: gi>=0?gi:null, controlIndex: opt.controlIndex ?? null, delay: 60, enabled:true, urlPattern: location.hostname, meta: opt.meta || {} }); }
  [...document.querySelectorAll("input:not([type]), input[type='text'], input[type='email'], input[type='tel'], input[type='number'], input[type='search'], input[type='url'], textarea, [contenteditable='true'], [role='textbox']")].filter(isVisible).forEach((el,i)=>{ const v=clean(el.value ?? el.textContent); if (v) add(el,"input",v,{controlIndex:i, matchedAttr:isMs&&clean(el.placeholder).toLowerCase().includes("answer")?"ms-react-other":"capture"}); });
  [...document.querySelectorAll("input[type='date'], input[type='datetime-local'], input[type='month'], input[type='time']")].filter(isVisible).forEach((el,i)=>{ if(el.value) add(el,"date",el.value,{controlIndex:i}); });
  [...document.querySelectorAll("select")].filter(isVisible).forEach((el,i)=>{ const text=clean(el.selectedOptions?.[0]?.textContent || el.value); if(text) add(el,"dropdown",text,{controlIndex:i}); });
  [...document.querySelectorAll("input[type='checkbox'], [role='checkbox']")].filter(isVisible).forEach((el,i)=>{ const checked=el instanceof HTMLInputElement ? el.checked : el.getAttribute("aria-checked")==="true"; add(el,"checkbox",String(checked),{controlIndex:i}); });
  [...document.querySelectorAll("input[type='radio']:checked, [role='radio'][aria-checked='true']")].filter(isVisible).forEach((el,i)=>{ const v=clean(el.value || el.getAttribute("aria-label") || el.textContent || "true"); add(el,"radio",v,{controlIndex:i}); });
  [...document.querySelectorAll("[role='combobox'], [aria-haspopup='listbox'], [aria-expanded][role='button'], button[aria-haspopup], div[aria-haspopup]")].filter(isVisible).forEach((el,i)=>{ let v=clean(el.getAttribute("aria-label") || el.textContent || el.title); v=v.replace(/^(select|selected|choice|question)\s*/i,"").trim(); if(v && v.length<100 && !/^open$/i.test(v)) add(el,"dropdown",v,{controlIndex:i}); });
  return out;
}

function runAutofill(rules) {
  const FIELD_DEFS = {
    fullName:[/^(.cc-)?name$/i,/full.?name/i,/your.?name/i,/^name$/i], firstName:[/given.?name/i,/first.?name/i,/fname/i,/forename/i], lastName:[/family.?name/i,/last.?name/i,/surname/i,/lname/i], email:[/^email$/i,/e-?mail/i,/email.?address/i], phone:[/^tel$/i,/phone/i,/mobile/i,/telephone/i], address1:[/address.?line.?1/i,/street.?address/i,/address1/i], address2:[/address.?line.?2/i,/address2/i], city:[/city/i,/suburb/i,/town/i], state:[/state/i,/province/i,/region/i], postcode:[/postal.?code/i,/post.?code/i,/zip/i], country:[/country/i], company:[/organization/i,/organisation/i,/company/i], jobTitle:[/job.?title/i,/position/i,/role/i], username:[/user.?name/i,/login/i]
  };
  const clean=s=>String(s||"").replace(/\s+/g," ").trim(); const low=s=>clean(s).toLowerCase(); const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  function expandValue(value){ const d=new Date(); const pad=n=>String(n).padStart(2,"0"); const rand=n=>Math.floor(Math.random()*n); return String(value ?? "").replace(/{{\s*date:today\s*}}/gi, `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`).replace(/{{\s*today\s*}}/gi, `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`).replace(/{{\s*randomEmail\s*}}/gi, `test${Date.now()}${rand(999)}@example.com`).replace(/{{\s*randomPhone\s*}}/gi, `04${String(10000000+rand(89999999)).slice(0,8)}`).replace(/{{\s*uuid\s*}}/gi, crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${rand(999999)}`); }
  function mark(el, ok=true){ if(!el) return; const old=el.style.boxShadow; el.style.boxShadow = ok ? "0 0 0 3px rgba(16,185,129,.55)" : "0 0 0 3px rgba(239,68,68,.55)"; setTimeout(()=>{ el.style.boxShadow=old; }, 1600); } const isMs=/forms\.cloud\.microsoft|forms\.office\.com|forms\.microsoft\.com/i.test(location.hostname);
  const visible=el=>{ if(!el||el.disabled) return false; const st=getComputedStyle(el), r=el.getBoundingClientRect(); return st.display!=="none"&&st.visibility!=="hidden"&&r.width>0&&r.height>0; };
  const cssEsc=window.CSS?.escape || (v=>String(v).replace(/[^a-zA-Z0-9_-]/g,"\\$&"));
  const groups=()=>[...document.querySelectorAll("[data-automation-id*='question'], [data-automation-id*='Question'], [role='radiogroup'], [role='group'], .office-form-question, .question, li, section")].filter(visible);
  const groupForIndex=i=>Number.isInteger(i)&&i>=0?groups()[i]:null;
  const groupOf=el=>groups().find(g=>g.contains(el));
  const textOf=el=>clean(["aria-label","aria-labelledby","aria-describedby","autocomplete","id","name","placeholder","title","data-testid","data-automation-id","value"].map(a=>el.getAttribute?.(a)).filter(Boolean).join(" ")+" "+(el.labels?[...el.labels].map(l=>l.textContent).join(" "):"")+" "+(groupOf(el)?.innerText||"")+" "+(el.textContent||""));
  const typeOf=p=>{ p=clean(p); if(!p)return"partial"; if(p.startsWith("//")||p.startsWith("/html/"))return"xpath"; if(p.startsWith("/")&&p.lastIndexOf("/")>0)return"regex"; if(p.startsWith('"')&&p.endsWith('"'))return"exact"; if(/^[.#\[]|^(input|select|textarea|button|div|span|label|form)\b/i.test(p))return"css"; return"partial"; };
  const match=(val,pat,t)=>{ val=clean(val); pat=clean(pat); if(!val||!pat)return false; if(t==="exact")return val===pat.replace(/^"|"$/g,""); if(t==="regex"){const m=pat.match(/^\/(.*)\/([gimsuy]*)$/); try{return m?new RegExp(m[1],m[2]).test(val):false}catch{return false}} return low(val).includes(low(pat.replace(/^"|"$/g,""))); };
  const inputs=()=>[...document.querySelectorAll("input:not([type]), input[type='text'], input[type='email'], input[type='tel'], input[type='number'], input[type='search'], input[type='url'], textarea, [contenteditable='true'], [role='textbox']")].filter(visible);
  const dates=()=>[...document.querySelectorAll("input[type='date'], input[type='datetime-local'], input[type='month'], input[type='time']")].filter(visible);
  const drops=()=>[...document.querySelectorAll("select, [role='combobox'], [aria-haspopup='listbox'], [aria-expanded][role='button'], button[aria-haspopup], div[aria-haspopup]")].filter(visible);
  const checks=()=>[...document.querySelectorAll("input[type='checkbox'], [role='checkbox']")].filter(visible);
  const radios=()=>[...document.querySelectorAll("input[type='radio'], [role='radio']")].filter(visible);
  function cands(rule, scope=document){ if(rule.type==="dropdown") return drops().filter(e=>scope===document||scope.contains(e)); if(rule.type==="checkbox") return checks().filter(e=>scope===document||scope.contains(e)); if(rule.type==="radio") return radios().filter(e=>scope===document||scope.contains(e)); if(rule.type==="date") return dates().filter(e=>scope===document||scope.contains(e)); return inputs().filter(e=>scope===document||scope.contains(e)); }
  function find(rule){
    const p=rule.pattern||rule.selector||rule.fieldKey, t=rule.patternType||typeOf(p);
    if (rule.groupIndex!==null && rule.groupIndex!==undefined) { const g=groupForIndex(Number(rule.groupIndex)); if(g){ const arr=cands(rule,g); if(rule.type==="input" && rule.matchedAttr==="ms-react-other"){ const ans=arr.find(e=>low(e.placeholder).includes("answer")||low(textOf(e)).includes("answer")); if(ans) return ans; } if(arr.length) return arr[Math.min(Number(rule.controlIndex)||0, arr.length-1)]; } }
    if (rule.type==="smart" && rule.fieldKey) return bestSemantic(rule.fieldKey, rule.value);
    if (t==="css") { try{const e=document.querySelector(p); if(e&&visible(e))return e;}catch{} }
    if (t==="xpath") { try{const e=document.evaluate(p,document,null,XPathResult.FIRST_ORDERED_NODE_TYPE,null).singleNodeValue; if(e&&visible(e))return e;}catch{} }
    let best=null,score=-1; for(const e of cands(rule)){ let s=0; if(match(textOf(e),p,t)) s+=70; if(e.id && document.querySelector(`label[for="${cssEsc(e.id)}"]`) && match(document.querySelector(`label[for="${cssEsc(e.id)}"]`).textContent,p,t)) s+=25; if(s>score){score=s;best=e;} } return score>0?best:null;
  }
  function bestSemantic(key){ const defs=FIELD_DEFS[key]||[]; let best=null,score=-1; for(const e of inputs().concat(dates())){ const attrs={autocomplete:e.getAttribute("autocomplete")||"",name:e.name||"",id:e.id||"",placeholder:e.placeholder||"",aria:e.getAttribute("aria-label")||"",label:e.labels?[...e.labels].map(l=>l.textContent).join(" "):"", group: groupOf(e)?.innerText||""}; let s=0; for(const re of defs){ if(re.test(attrs.autocomplete))s=Math.max(s,100); if(re.test(attrs.name))s=Math.max(s,90); if(re.test(attrs.id))s=Math.max(s,85); if(re.test(attrs.aria))s=Math.max(s,80); if(re.test(attrs.placeholder))s=Math.max(s,70); if(re.test(attrs.label))s=Math.max(s,65); if(re.test(attrs.group))s=Math.max(s,45); } if(s>score){score=s;best=e;} } return score>=45?best:null; }
  function setVal(el,value){ value=expandValue(value); mark(el,true); el.focus(); if(el.isContentEditable||el.getAttribute("role")==="textbox"){ el.textContent=value; } else { const proto=el instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype; const setter=Object.getOwnPropertyDescriptor(proto,"value")?.set; setter?setter.call(el,value):(el.value=value); } el.dispatchEvent(new InputEvent("input",{bubbles:true,inputType:"insertText",data:value})); el.dispatchEvent(new Event("change",{bubbles:true})); }
  function setSelect(sel,w){ const opt=[...sel.options].find(o=>low(o.textContent)===low(w)||low(o.textContent).includes(low(w))||o.value===w); if(!opt)return false; mark(sel,true); sel.value=opt.value; sel.dispatchEvent(new Event("input",{bubbles:true})); sel.dispatchEvent(new Event("change",{bubbles:true})); return true; }
  async function option(w, timeout=1100){ const start=Date.now(); while(Date.now()-start<timeout){ const opts=[...document.querySelectorAll("[role='option'], [role='menuitemradio'], li[role='option']")].filter(visible); const hit=opts.find(o=>low(o.getAttribute("aria-label")||o.textContent).includes(low(w))); if(hit)return hit; await sleep(60); } return null; }
  function toast(msg,type="success"){ const t=document.createElement("div"); t.textContent=msg; t.style.cssText=`position:fixed;top:18px;right:18px;z-index:2147483647;padding:12px 16px;border-radius:14px;font:700 13px system-ui;background:${type==="error"?"#ef4444":"#10b981"};color:#fff;box-shadow:0 14px 30px rgba(0,0,0,.24)`; document.documentElement.appendChild(t); setTimeout(()=>t.remove(),2200); }
  async function waitGroupInput(gi, beforeCount){ if(!Number.isInteger(gi)||gi<0)return; const start=Date.now(); while(Date.now()-start<900){ const g=groupForIndex(gi); if(g && cands({type:"input"},g).length>beforeCount) return; await sleep(50); } }
  async function run(){ let changed=0; const priority={dropdown:1,radio:2,checkbox:3,smart:4,input:5,date:6,click:7,submit:8,wait:9}; const sorted=[...rules].filter(r=>r.enabled!==false).sort((a,b)=>(priority[a.type]||50)-(priority[b.type]||50)); for(const rule of sorted){ if(rule.type==="wait"){await sleep(Number(rule.value)||300); continue;} const el=find(rule); if(!el) continue; if(["input","date","smart"].includes(rule.type)){ setVal(el,rule.value); changed++; } else if(rule.type==="checkbox"){ const want=rule.value===true||rule.value==="true"; const checked=el instanceof HTMLInputElement?el.checked:el.getAttribute("aria-checked")==="true"; if(checked!==want) el.click(); changed++; } else if(rule.type==="radio"){ el.click(); changed++; } else if(rule.type==="dropdown"){ const gi=Number.isInteger(rule.groupIndex)?rule.groupIndex:null; const before=gi!==null && groupForIndex(gi)?cands({type:"input"},groupForIndex(gi)).length:0; if(el instanceof HTMLSelectElement){ if(setSelect(el,rule.value)) changed++; } else { el.click(); const opt=await option(rule.value); if(opt){ opt.click(); changed++; await waitGroupInput(gi,before); } } } else if(rule.type==="click"||rule.type==="submit"){ el.click(); changed++; } await sleep(Math.min(Number(rule.delay)||60,700)); } toast(changed?`✓ Autofilled ${changed} field${changed===1?"":"s"}`:"No matching fields found",changed?"success":"error"); }
  run();
}
load(() => { renderProfiles(); renderRules(); renderIdentity(); });
