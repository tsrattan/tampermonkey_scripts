const EMPTY_IDENTITY = { fullName:'', firstName:'', lastName:'', email:'', phone:'', address1:'', address2:'', city:'', state:'', postcode:'', country:'', company:'', jobTitle:'', username:'' };
const DEFAULT_PROFILE = { Default: { rules: [], identity: { ...EMPTY_IDENTITY } } };
const statusEl = document.getElementById('status');
const pasteBox = document.getElementById('pasteBox');
const dropZone = document.getElementById('dropZone');

function setStatus(message, ok = true) {
  statusEl.textContent = message;
  statusEl.className = 'status ' + (ok ? 'ok' : 'err');
}

function detectPatternType(pattern) {
  const p = String(pattern || '').trim();
  if (!p) return 'partial';
  if (p.startsWith('//') || p.startsWith('/html/')) return 'xpath';
  if (p.startsWith('/') && p.lastIndexOf('/') > 0) return 'regex';
  if (p.startsWith('"') && p.endsWith('"')) return 'exact';
  if (/^[.#\[]|^(input|select|textarea|button|div|span|label|form)\b/i.test(p)) return 'css';
  return 'partial';
}

function normaliseRule(rule = {}) {
  const pattern = rule.pattern || rule.selector || rule.fieldKey || '';
  return {
    id: rule.id || (crypto.randomUUID ? crypto.randomUUID() : String(Date.now() + Math.random())),
    type: rule.type || (rule.fieldKey ? 'smart' : 'input'),
    fieldKey: rule.fieldKey || '',
    pattern,
    selector: rule.selector || (detectPatternType(pattern) === 'css' ? pattern : ''),
    patternType: rule.patternType || detectPatternType(pattern),
    matchedAttr: rule.matchedAttr || (rule.fieldKey ? 'semantic' : rule.selector ? 'css' : 'manual'),
    value: rule.value ?? '',
    order: Number.isFinite(Number(rule.order)) ? Number(rule.order) : 0,
    groupIndex: Number.isFinite(Number(rule.groupIndex)) ? Number(rule.groupIndex) : null,
    controlIndex: Number.isFinite(Number(rule.controlIndex)) ? Number(rule.controlIndex) : null,
    delay: Number.isFinite(Number(rule.delay)) ? Number(rule.delay) : 80,
    enabled: rule.enabled !== false,
    urlPattern: rule.urlPattern || '',
    meta: rule.meta || {}
  };
}

function normaliseIdentity(identity = {}) {
  const out = { ...EMPTY_IDENTITY };
  Object.keys(out).forEach(key => { out[key] = String(identity?.[key] ?? '').trim(); });
  if (!out.fullName && (out.firstName || out.lastName)) out.fullName = `${out.firstName} ${out.lastName}`.trim();
  return out;
}
function normaliseProfiles(input) {
  const src = input && typeof input === 'object' ? input : DEFAULT_PROFILE;
  const out = {};
  Object.entries(src).forEach(([name, profile]) => {
    const cleanName = String(name || 'Default').trim() || 'Default';
    out[cleanName] = {
      rules: Array.isArray(profile?.rules) ? profile.rules.map(normaliseRule) : [],
      identity: normaliseIdentity(profile?.identity || profile?.profile || {})
    };
  });
  return Object.keys(out).length ? out : structuredClone(DEFAULT_PROFILE);
}

async function importJsonText(text) {
  let imported;
  try {
    imported = JSON.parse(text);
  } catch {
    setStatus('Invalid JSON file/content.', false);
    return;
  }

  const incoming = normaliseProfiles(imported.profiles || imported);
  chrome.storage.local.get(['profiles', 'activeProfile'], data => {
    const existing = normaliseProfiles(data.profiles);
    const profiles = normaliseProfiles({ ...existing, ...incoming });
    const activeProfile = imported.activeProfile && profiles[imported.activeProfile]
      ? imported.activeProfile
      : Object.keys(incoming)[0] || data.activeProfile || Object.keys(profiles)[0];

    chrome.storage.local.set({ profiles, activeProfile }, () => {
      if (chrome.runtime.lastError) {
        setStatus(chrome.runtime.lastError.message, false);
        return;
      }
      const count = Object.values(incoming).reduce((sum, profile) => sum + (profile.rules?.length || 0), 0);
      const identityCount = Object.values(incoming).reduce((sum, profile) => sum + Object.values(profile.identity || {}).filter(Boolean).length, 0);
      setStatus(`Imported ${Object.keys(incoming).length} profile(s), ${count} rule(s), ${identityCount} identity field(s). Open the extension popup again to see them.`);
    });
  });
}

function importFile(file) {
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => importJsonText(String(reader.result || ''));
  reader.onerror = () => setStatus('Could not read that file.', false);
  reader.readAsText(file);
}


document.getElementById('importPasteBtn').addEventListener('click', () => {
  const text = pasteBox.value.trim();
  if (!text) return setStatus('Paste exported JSON first.', false);
  importJsonText(text);
});
document.getElementById('closeBtn').addEventListener('click', () => window.close());

['dragenter', 'dragover'].forEach(type => dropZone.addEventListener(type, e => {
  e.preventDefault();
  dropZone.classList.add('drag');
}));
['dragleave', 'drop'].forEach(type => dropZone.addEventListener(type, e => {
  e.preventDefault();
  dropZone.classList.remove('drag');
}));
dropZone.addEventListener('drop', e => importFile(e.dataTransfer?.files?.[0]));
